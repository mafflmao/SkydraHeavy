namespace LibSkydra
{
	public class igCachedAttrListList : igObjectList
	{
		
		public igCachedAttrListList(IGZ igz) : base(igz){}
	}
}