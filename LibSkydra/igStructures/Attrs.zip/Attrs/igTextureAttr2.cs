// It's impossible to know what namespace this is under currently so i'm assuming Attr since its name ends in Attr
namespace LibSkydra
{
	public class igTextureAttr2 : igObject
	{
		[igUnsignedIntMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_magFilter", 0x18)]
		public IG_GFX_TEXTURE_FILTER magFilter;

		[igUnsignedIntMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_minFilter", 0x1C)]
		public IG_GFX_TEXTURE_FILTER minFilter;

		[igUnsignedIntMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_wrapS", 0x20)]
		public IG_GFX_TEXTURE_WRAP wrapS;

		[igUnsignedIntMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_wrapT", 0x24)]
		public IG_GFX_TEXTURE_WRAP wrapT;

		[igUnsignedIntMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_msaaType", 0x28)]
		public IG_GFX_MULTISAMPLE_TYPE msaaType;

		[igUnsignedIntMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_source", 0x2C)]
		public IG_GFX_TEXTURE_SOURCE source;

		[igObjectRefMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_image", 0x30)]
		public igImage2 image;

		[igUnsignedIntMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_formatHint", 0x10)]
		public uint formatHint;

		[igIntMetaField(0x08, IG_CORE_PLATFORM.DEFAULT, "_videoBuffer", 0x34)]
		public object videoBuffer;

		[igIntMetaField(0x06, IG_CORE_PLATFORM.DEFAULT, "_texHandle", 0x34)]
		[igIntMetaField(0x08, IG_CORE_PLATFORM.DEFAULT, "_texHandle", 0x38)]
		public int texHandle;

		[igHandleMetaField(0x06, IG_CORE_PLATFORM.DEFAULT, "_imageHandle", 0x38)]
		[igHandleMetaField(0x08, IG_CORE_PLATFORM.DEFAULT, "_imageHandle", 0x3C)]
		public Tuple<string, string> imageHandle;

		[igTStaticMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_preloadTexture", 0xFFFF)]
		public static object preloadTexture;

		[igBoolMetaField(0x06, IG_CORE_PLATFORM.DEFAULT, "_loadInVramForCtr", 0x14)]
		public bool loadInVramForCtr;

		[igUnsignedIntMetaField(0x06, IG_CORE_PLATFORM.DEFAULT, "_wrapR", 0x3C)]
		[igUnsignedIntMetaField(0x08, IG_CORE_PLATFORM.DEFAULT, "_wrapR", 0x40)]
		public IG_GFX_TEXTURE_WRAP wrapR;

		[igBoolMetaField(0x08, IG_CORE_PLATFORM.DEFAULT, "_wrapR", 0x44)]
		public bool filterFixedUp;

		public igTextureAttr2(IGZ parent) : base(parent){}
	}
}