namespace LibSkydra
{
	public class igVisualAttribute : igAttr
	{
		public igVisualAttribute(IGZ igz) : base(igz){}
	}
}