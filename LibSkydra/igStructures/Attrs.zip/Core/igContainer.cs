namespace LibSkydra
{
	public class igContainer : igObject
	{
		public igContainer(IGZ igz) : base(igz){}
	}
}