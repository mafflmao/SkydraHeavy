namespace LibSkydra
{
	public struct igHandle
	{
		public uint hash;
		public uint type;
	}
}