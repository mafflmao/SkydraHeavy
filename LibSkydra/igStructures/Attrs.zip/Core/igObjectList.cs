namespace LibSkydra
{
	public class igObjectList : igTDataList<igObject>
	{
		public igObjectList(IGZ igz) : base(igz){}
	}
}