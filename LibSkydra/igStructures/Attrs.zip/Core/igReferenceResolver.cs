namespace LibSkydra
{
	public class igReferenceResolver : igNamedObject
	{
		public igReferenceResolver(IGZ igz) : base(igz){}
	}
}