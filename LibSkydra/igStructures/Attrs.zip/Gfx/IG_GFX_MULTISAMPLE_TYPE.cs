namespace LibSkydra
{
	//I'm praying this stays the same on all verions lol
	public enum IG_GFX_MULTISAMPLE_TYPE : uint
	{
		NONE = 0,
		_2X = 1,			//Actually 2X
		_4X = 2,			//Actually 4X
		_4X_ROTATED = 3,	//Actually 4X_ROTATED
	}
}