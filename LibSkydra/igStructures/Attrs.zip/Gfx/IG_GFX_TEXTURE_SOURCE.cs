namespace LibSkydra
{
	//I'm praying this stays the same on all verions lol
	public enum IG_GFX_TEXTURE_SOURCE : uint
	{
		IMAGE = 0,
		BUFFER = 3,
	}
}