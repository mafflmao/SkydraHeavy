namespace LibSkydra
{
	//I'm praying this stays the same on all verions lol
	public enum IG_GFX_TEXTURE_WRAP : uint
	{
		CLAMP = 0,
		REPEAT = 1,
		REGION_CLAMP = 2,
		REGION_REPEAT = 3,
		BORDER = 4,
	}
}