namespace LibSkydra
{
	public class igImage2 : igNamedObject
	{
		[igUnsignedShortMetaField(0x09, IG_CORE_PLATFORM.DEFAULT, "_width", 0x34)]
		[igUnsignedShortMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_width", 0x30)]
		public ushort width;

		[igUnsignedShortMetaField(0x09, IG_CORE_PLATFORM.DEFAULT, "_height", 0x36)]
		[igUnsignedShortMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_height", 0x32)]
		public ushort height;

		[igUnsignedShortMetaField(0x09, IG_CORE_PLATFORM.DEFAULT, "_depth", 0x38)]
		[igUnsignedShortMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_depth", 0x34)]
		public ushort depth;

		[igUnsignedShortMetaField(0x09, IG_CORE_PLATFORM.DEFAULT, "_levelCount", 0x3A)]
		[igUnsignedShortMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_levelCount", 0x36)]
		public ushort levelCount;

		[igUnsignedShortMetaField(0x09, IG_CORE_PLATFORM.DEFAULT, "_imageCount", 0x3C)]
		[igUnsignedShortMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_imageCount", 0x38)]
		public ushort imageCount;

		[igObjectRefMetaField(0x09, IG_CORE_PLATFORM.DEFAULT, "_format", 0x40)]
		[igObjectRefMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_format", 0x3C)]
		public metaimages format;

		[igIntMetaField(0x09, IG_CORE_PLATFORM.DEFAULT, "_usageDeprecated", 0x44)]
		[igIntMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_usageDeprecated", 0x40)]
		public int usage;

		[igUnsignedShortMetaField(0x09, IG_CORE_PLATFORM.DEFAULT, "_paddingDeprecated", 0x48)]
		[igUnsignedShortMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_paddingDeprecated", 0x44)]
		public ushort padding;

		[igMemoryRefHandleMetaField(0x09, IG_CORE_PLATFORM.DEFAULT, "_data", 0x4C)]
		[igMemoryRefHandleMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_data", 0x48)]
		public igMemory data;

		[igIntMetaField(0x09, IG_CORE_PLATFORM.DEFAULT, "_lockCount", 0x50)]
		[igIntMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_lockCount", 0x4C)]
		public int lockCount;
	
		[igIntMetaField(0x09, IG_CORE_PLATFORM.DEFAULT, "_texHandle", 0x54)]
		[igIntMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_texHandle", 0x50)]
		public int texHandle;

		//TODO: Implement igRawRefMetaField for field _lockedMemory
		[igIntMetaField(0x06, IG_CORE_PLATFORM.DEFAULT, "_lockedMemory", 0x54)]
		[igIntMetaField(0x08, IG_CORE_PLATFORM.DEFAULT, "_lockedMemory", 0x54)]
		public int lockMemory;

		[igBoolMetaField(0x08, IG_CORE_PLATFORM.DEFAULT, "_oglDiscardOriginalImage", 0x58)]
		[igBoolMetaField(0x09, IG_CORE_PLATFORM.DEFAULT, "_oglDiscardOriginalImage", 0x5C)]
		[igBoolMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_oglDiscardOriginalImage", 0x5C)]
		public bool oglDiscardOriginalImage;

		[igTStaticMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_makeAbstract", 0xFFFF)]
		public object makeAbstract;

		[igTStaticMetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_makeConcrete", 0xFFFF)]
		public object makeConcrete;

		[igVec4MetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_colorScale", 0x10)]
		public Vector4 colorScale;

		[igVec4MetaField(0xFF, IG_CORE_PLATFORM.DEFAULT, "_colorBias", 0x20)]
		public Vector4 colorBias;

		//Note: There is an igObjectRefMetaField called _graphicsHelper at 0x30 but idk what it does so it's not included here

		public igImage2(IGZ parent) : base(parent){}

		public byte[] ToDDS()
		{
			byte[] ddsHeader = new byte[]
			{
				0x44, 0x44, 0x53, 0x20,		// "DDS "
				0x7C, 0x00, 0x00, 0x00,		// Version Info
				0x07, 0x10, 0x0A, 0x00,		// More Version Info
				0x00, 0x00, 0x00, 0x00,		// Height
				0x00, 0x00, 0x00, 0x00,		// Width
				0x00, 0x00, 0x00, 0x00,		// Size
				0x00, 0x00, 0x00, 0x00,		// 
				0x00, 0x00, 0x00, 0x00,		// Mipmaps 
				0x00, 0x00, 0x00, 0x00,		// 
				0x00, 0x00, 0x00, 0x00,		// 
				0x00, 0x00, 0x00, 0x00,		// 
				0x00, 0x00, 0x00, 0x00,		// 
				0x00, 0x00, 0x00, 0x00,		// 
				0x00, 0x00, 0x00, 0x00,		// 
				0x00, 0x00, 0x00, 0x00,		// 
				0x00, 0x00, 0x00, 0x00,		// 
				0x00, 0x00, 0x00, 0x00,		// 
				0x00, 0x00, 0x00, 0x00,		// 
				0x00, 0x00, 0x00, 0x00,		// 
				0x20, 0x00, 0x00, 0x00,		// 
				0x04, 0x00, 0x00, 0x00,		// 
				0x44, 0x58, 0x54, 0x30,		// "DXT0"
				0x00, 0x00, 0x00, 0x00,		// 
				0x00, 0x00, 0x00, 0x00,		// 
				0x00, 0x00, 0x00, 0x00,		// 
				0x00, 0x00, 0x00, 0x00,		// 
				0x00, 0x00, 0x00, 0x00,		// 
				0x08, 0x10, 0x40, 0x00,		// 
				0x00, 0x00, 0x00, 0x00,		// 
				0x00, 0x00, 0x00, 0x00,		// 
				0x00, 0x00, 0x00, 0x00,		// 
				0x00, 0x00, 0x00, 0x00 		// 
			};

			MemoryStream ddsStream = new MemoryStream();
			ddsStream.Write(ddsHeader);
			ddsStream.Seek(0x0C, SeekOrigin.Begin);
			ddsStream.Write(BitConverter.GetBytes((uint)height), 0x00, 0x04);
			ddsStream.Write(BitConverter.GetBytes((uint)width), 0x00, 0x04);
			ddsStream.Write(BitConverter.GetBytes(data.dataLength), 0x00, 0x04);
			ddsStream.Seek(0x1C, SeekOrigin.Begin);
			ddsStream.Write(BitConverter.GetBytes((uint)levelCount), 0x00, 0x04);
			ddsStream.Seek(0x57, SeekOrigin.Begin);
			Console.WriteLine($"format = {format.ToString()}");
			int stride = 0;
			if(format.ToString().StartsWith("dxt1"))
			{
				stride = 0x08;
				ddsStream.Write(BitConverter.GetBytes((byte)0x31), 0x00, 0x01);
			}
			else if(format.ToString().StartsWith("dxt5"))
			{
				stride = 0x10;
				ddsStream.Write(BitConverter.GetBytes((byte)0x35), 0x00, 0x01);
			}
			ddsStream.Seek(0x80, SeekOrigin.Begin);
			Console.WriteLine($"data length = {data.dataLength}");
			for(int i = 0; i < data.dataLength; i += stride)
			{
				if(format.ToString().EndsWith("_big_wii"))
				{
					//width must be rounded up to nearest 4
					int alignedWidth = ((width + 3) / 4) * 4;

					//if we wanted the actual x and y block indexes we would've used (width >> 2) but since 2x2 sets of blocks are stored as 4x1 sets of blocks, we pretend the image is double the width
					int xindex = ((i / stride) % (alignedWidth >> 1)) >> 1;
					int yindex = ((i / stride) / (alignedWidth >> 1)) << 1;

					//We're reading 4x1 sets of blocks
					byte[] currentBlocks = new byte[stride * 4];
					Array.Copy(data.data, i, currentBlocks, 0, currentBlocks.Length);

					//Fixing the endianness of the 2 r5g6b5 colours
					for(int j = 0; j < 4; j++)
					{
						Array.Reverse(currentBlocks, stride * j + 0, 2);
						Array.Reverse(currentBlocks, stride * j + 2, 2);
					}
					//Flipping the pixels within each block horizontally
					for(int j = 0; j < currentBlocks.Length; j += 8)
					{
						byte[] currentRow = new byte[4];
						Array.Copy(currentBlocks, j + 4, currentRow, 0, 4);
						for(int k = 0; k < 4; k++)
						{
							currentRow[k] = (byte)(((currentRow[k] & 3) << 6) | ((currentRow[k] & 12) << 2) | ((currentRow[k] & 48) >> 2) | ((currentRow[k] & 192) >> 6));
						}
						Array.Copy(currentRow, 0, currentBlocks, j + 4, 4);
					}

					//Writing the two blocks that would normally be on this row
					ddsStream.Seek(0x80 + (xindex + yindex * (alignedWidth >> 2)) * stride, SeekOrigin.Begin);
					ddsStream.Write(currentBlocks, 0, stride * 2);

					//Writing the two blocks that would be above the previous two
					ddsStream.Seek(0x80 + (xindex + (yindex + 1) * (alignedWidth >> 2)) * stride, SeekOrigin.Begin);
					ddsStream.Write(currentBlocks, stride * 2, stride * 2);

					//We dealt with 4 blocks instead of 1 so here we make sure the for loop doesn't run more than it has to
					i += stride * 3;
					continue;
				}
				else
				{
					ddsStream.Write(data.data, i, stride);
				}
			}
			ddsStream.Flush();
			return ddsStream.ToArray();
		}
	}
}