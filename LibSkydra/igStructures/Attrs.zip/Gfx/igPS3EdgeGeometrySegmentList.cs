namespace LibSkydra
{
	public class igPS3EdgeGeometrySegmentList : igObjectList
	{
		
		public igPS3EdgeGeometrySegmentList(IGZ igz) : base(igz){}
	}
}