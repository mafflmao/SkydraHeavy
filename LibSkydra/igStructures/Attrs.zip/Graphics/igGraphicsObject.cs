namespace LibSkydra
{
	public class igGraphicsObject : igObject
	{
		public igGraphicsObject(IGZ igz) : base(igz) {}
	}
}