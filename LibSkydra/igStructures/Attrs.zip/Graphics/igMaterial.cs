namespace LibSkydra
{
	public class igMaterial : igNamedObject
	{
		public igMaterial(IGZ igz) : base(igz) {}
	}
}