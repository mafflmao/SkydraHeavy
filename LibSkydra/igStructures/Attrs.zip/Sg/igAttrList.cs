namespace LibSkydra
{
	public class igAttrList : igNodeList
	{
		public igAttrList(IGZ igz) : base(igz){}
	}
}