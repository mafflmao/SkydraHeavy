namespace LibSkydra
{
	public class igGeometry : igAttrSet
	{
		public igGeometry(IGZ igz) : base(igz){}

		public void ExtractGeometry(out uint[][] indices, out float[][] vertices)
		{
			if(parent.platform == IG_CORE_PLATFORM.PS3)
			{
				(attributes.tdata.First(x => x is igEdgeGeometryAttr) as igEdgeGeometryAttr).geometry.ExtractGeometry(out indices, out vertices);
			}
			else throw new InvalidOperationException($"Platform {parent.platform.ToString()} is not supported");
		}
	}
}