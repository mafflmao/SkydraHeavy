namespace LibSkydra
{
	public class igNodeList : igObjectList
	{
		public igNodeList(IGZ igz) : base(igz){}
	}
}