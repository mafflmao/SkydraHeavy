import os

def remove_dots_from_cs_files(base_directory):
    # Walk through the directory
    for root, dirs, files in os.walk(base_directory):
        # Check if the directory starts with "tfb"
        if os.path.basename(root).startswith("tfb"):
            for file in files:
                if file.endswith(".cs"):
                    file_path = os.path.join(root, file)
                    try:
                        # Check if '...' is in the filename
                        if '...' in file:
                            # Create new filename by removing '...'
                            new_file_name = file.replace('...', '')
                            new_file_path = os.path.join(root, new_file_name)
                            
                            # Rename the file
                            os.rename(file_path, new_file_path)
                            print(f"Renamed: {file_path} to {new_file_path}")

                        # Read the file content
                        with open(new_file_path if '...' in file else file_path, 'r', encoding='utf-8') as f:
                            content = f.read()

                        # Check if '...' is in the content
                        if '...' in content:
                            # Remove '...' from content
                            updated_content = content.replace('...', '')
                            
                            # Write the updated content back to the file
                            with open(new_file_path if '...' in file else file_path, 'w', encoding='utf-8') as f:
                                f.write(updated_content)
                            print(f"Updated content in: {new_file_path if '...' in file else file_path}")
                    except Exception as e:
                        print(f"Error processing file {file_path}: {e}")

# Set your base directory here
base_directory = 'D:/Skydra-src (1)/LibSkydra/igStructures'
remove_dots_from_cs_files(base_directory)
