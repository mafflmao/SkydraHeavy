namespace LibSkydra
{
    public class ActorInfoList : igObject 
    {
        public ActorInfoList(IGZ igz) : base(igz) { } 
    }
}
