namespace LibSkydra
{
    public class ActorInterfaceResolver : igObject 
    {
        public ActorInterfaceResolver(IGZ igz) : base(igz) { } 
    }
}
