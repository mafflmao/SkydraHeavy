namespace LibSkydra
{
    public class ActorParameters : igObject 
    {
        public ActorParameters(IGZ igz) : base(igz) { } 
    }
}
