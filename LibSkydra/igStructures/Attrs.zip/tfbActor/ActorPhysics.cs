namespace LibSkydra
{
    public class ActorPhysics : igObject 
    {
        public ActorPhysics(IGZ igz) : base(igz) { } 
    }
}
