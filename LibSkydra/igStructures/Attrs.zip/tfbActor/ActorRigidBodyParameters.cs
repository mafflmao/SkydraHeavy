namespace LibSkydra
{
    public class ActorRigidBodyParameters : igObject 
    {
        public ActorRigidBodyParameters(IGZ igz) : base(igz) { } 
    }
}
