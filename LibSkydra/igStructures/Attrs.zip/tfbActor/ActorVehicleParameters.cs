namespace LibSkydra
{
    public class ActorVehicleParameters : igObject 
    {
        public ActorVehicleParameters(IGZ igz) : base(igz) { } 
    }
}
