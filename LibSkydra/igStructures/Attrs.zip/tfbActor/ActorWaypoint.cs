namespace LibSkydra
{
    public class ActorWaypoint : igObject 
    {
        public ActorWaypoint(IGZ igz) : base(igz) { } 
    }
}
