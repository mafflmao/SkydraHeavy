namespace LibSkydra
{
    public class ActorWaypointList : igObject 
    {
        public ActorWaypointList(IGZ igz) : base(igz) { } 
    }
}
