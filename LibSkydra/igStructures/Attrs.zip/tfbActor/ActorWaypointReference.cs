namespace LibSkydra
{
    public class ActorWaypointReference : igObject 
    {
        public ActorWaypointReference(IGZ igz) : base(igz) { } 
    }
}
