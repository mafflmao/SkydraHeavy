namespace LibSkydra
{
    public class RigidBodyPhysics : igObject 
    {
        public RigidBodyPhysics(IGZ igz) : base(igz) { } 
    }
}
