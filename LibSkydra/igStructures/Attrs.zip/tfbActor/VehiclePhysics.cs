namespace LibSkydra
{
    public class VehiclePhysics : igObject 
    {
        public VehiclePhysics(IGZ igz) : base(igz) { } 
    }
}
