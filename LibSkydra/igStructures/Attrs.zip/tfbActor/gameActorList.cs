namespace LibSkydra
{
    public class gameActorList : igObject 
    {
        public gameActorList(IGZ igz) : base(igz) { } 
    }
}
