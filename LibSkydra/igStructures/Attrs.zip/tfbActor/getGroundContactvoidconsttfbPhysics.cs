namespace LibSkydra
{
    public class getGroundContactvoidconsttfbPhysics : igObject 
    {
        public getGroundContactvoidconsttfbPhysics(IGZ igz) : base(igz) { } 
    }
}
