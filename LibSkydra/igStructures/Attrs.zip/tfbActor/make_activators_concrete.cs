namespace LibSkydra
{
    public class make_activators_concrete : igObject 
    {
        public make_activators_concrete(IGZ igz) : base(igz) { } 
    }
}
