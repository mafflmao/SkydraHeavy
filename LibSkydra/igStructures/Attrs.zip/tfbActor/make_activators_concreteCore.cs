namespace LibSkydra
{
    public class make_activators_concreteCore : igObject 
    {
        public make_activators_concreteCore(IGZ igz) : base(igz) { } 
    }
}
