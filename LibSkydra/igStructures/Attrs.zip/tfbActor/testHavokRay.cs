namespace LibSkydra
{
    public class testHavokRay : igObject 
    {
        public testHavokRay(IGZ igz) : base(igz) { } 
    }
}
