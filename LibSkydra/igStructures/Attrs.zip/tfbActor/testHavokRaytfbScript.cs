namespace LibSkydra
{
    public class testHavokRaytfbScript : igObject 
    {
        public testHavokRaytfbScript(IGZ igz) : base(igz) { } 
    }
}
