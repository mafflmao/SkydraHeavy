namespace LibSkydra
{
    public class tfbActorGamePlugin : igObject 
    {
        public tfbActorGamePlugin(IGZ igz) : base(igz) { } 
    }
}
