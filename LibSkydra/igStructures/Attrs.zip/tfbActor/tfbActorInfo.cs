namespace LibSkydra
{
    public class tfbActorInfo : igNamedObject 
    {
        public tfbActorInfo(IGZ igz) : base(igz) { } 
    }
}
