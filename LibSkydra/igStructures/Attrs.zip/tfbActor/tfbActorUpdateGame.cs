namespace LibSkydra
{
    public class tfbActorUpdateGame : igObject 
    {
        public tfbActorUpdateGame(IGZ igz) : base(igz) { } 
    }
}
