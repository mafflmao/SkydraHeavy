namespace LibSkydra
{
    public class tfbCorpus : igObject 
    {
        public tfbCorpus(IGZ igz) : base(igz) { } 
    }
}
