namespace LibSkydra
{
    public class tfbGameActor : igObject 
    {
        public tfbGameActor(IGZ igz) : base(igz) { } 
    }
}
