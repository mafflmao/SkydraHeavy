namespace LibSkydra
{
    public class syncAnimationParameterstfbPhysics : igObject 
    {
        public syncAnimationParameterstfbPhysics(IGZ igz) : base(igz) { } 
    }
}
