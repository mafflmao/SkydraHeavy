namespace LibSkydra
{
    public class tfbAnimationControl : igObject 
    {
        public tfbAnimationControl(IGZ igz) : base(igz) { } 
    }
}
