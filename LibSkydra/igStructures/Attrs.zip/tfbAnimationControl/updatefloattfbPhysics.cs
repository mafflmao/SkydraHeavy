namespace LibSkydra
{
    public class updatefloattfbPhysics : igObject 
    {
        public updatefloattfbPhysics(IGZ igz) : base(igz) { } 
    }
}
