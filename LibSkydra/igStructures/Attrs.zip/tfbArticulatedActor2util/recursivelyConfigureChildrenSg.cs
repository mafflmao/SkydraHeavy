namespace LibSkydra
{
    public class recursivelyConfigureChildrenSg : igObject 
    {
        public recursivelyConfigureChildrenSg(IGZ igz) : base(igz) { } 
    }
}
