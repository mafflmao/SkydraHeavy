namespace LibSkydra
{
    public class TFBReplaceColorAttr : igObject 
    {
        public TFBReplaceColorAttr(IGZ igz) : base(igz) { } 
    }
}
