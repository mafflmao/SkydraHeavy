namespace LibSkydra
{
    public class TFBShaderScrollAttr : igObject 
    {
        public TFBShaderScrollAttr(IGZ igz) : base(igz) { } 
    }
}
