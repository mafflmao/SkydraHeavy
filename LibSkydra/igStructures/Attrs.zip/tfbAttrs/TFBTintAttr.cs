namespace LibSkydra
{
    public class TFBTintAttr : igObject 
    {
        public TFBTintAttr(IGZ igz) : base(igz) { } 
    }
}
