namespace LibSkydra
{
    public class TFBUserInfo : igObject 
    {
        public TFBUserInfo(IGZ igz) : base(igz) { } 
    }
}
