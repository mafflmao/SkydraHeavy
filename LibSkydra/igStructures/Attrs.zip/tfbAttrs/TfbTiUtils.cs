namespace LibSkydra
{
    public class TfbTiUtils : igObject 
    {
        public TfbTiUtils(IGZ igz) : base(igz) { } 
    }
}
