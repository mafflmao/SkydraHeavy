namespace LibSkydra
{
    public class blackWhitePS : igObject 
    {
        public blackWhitePS(IGZ igz) : base(igz) { } 
    }
}
