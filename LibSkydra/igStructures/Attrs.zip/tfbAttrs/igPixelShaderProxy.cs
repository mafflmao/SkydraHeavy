namespace LibSkydra
{
    public class igPixelShaderProxy : igObject 
    {
        public igPixelShaderProxy(IGZ igz) : base(igz) { } 
    }
}
