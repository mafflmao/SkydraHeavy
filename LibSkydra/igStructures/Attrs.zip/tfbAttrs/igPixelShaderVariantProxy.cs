namespace LibSkydra
{
    public class igPixelShaderVariantProxy : igObject 
    {
        public igPixelShaderVariantProxy(IGZ igz) : base(igz) { } 
    }
}
