namespace LibSkydra
{
    public class igPlatformPixelShaderProxy : igObject 
    {
        public igPlatformPixelShaderProxy(IGZ igz) : base(igz) { } 
    }
}
