namespace LibSkydra
{
    public class igPlatformVertexShaderProxy : igObject 
    {
        public igPlatformVertexShaderProxy(IGZ igz) : base(igz) { } 
    }
}
