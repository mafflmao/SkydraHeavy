namespace LibSkydra
{
    public class igTechniqueProxy : igObject 
    {
        public igTechniqueProxy(IGZ igz) : base(igz) { } 
    }
}
