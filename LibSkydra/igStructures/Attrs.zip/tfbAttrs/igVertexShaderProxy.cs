namespace LibSkydra
{
    public class igVertexShaderProxy : igObject 
    {
        public igVertexShaderProxy(IGZ igz) : base(igz) { } 
    }
}
