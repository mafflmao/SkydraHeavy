namespace LibSkydra
{
    public class igVertexShaderVariantProxy : igObject 
    {
        public igVertexShaderVariantProxy(IGZ igz) : base(igz) { } 
    }
}
