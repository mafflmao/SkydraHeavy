namespace LibSkydra
{
    public class particle_PS : igObject 
    {
        public particle_PS(IGZ igz) : base(igz) { } 
    }
}
