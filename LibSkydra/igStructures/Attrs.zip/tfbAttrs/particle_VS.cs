namespace LibSkydra
{
    public class particle_VS : igObject 
    {
        public particle_VS(IGZ igz) : base(igz) { } 
    }
}
