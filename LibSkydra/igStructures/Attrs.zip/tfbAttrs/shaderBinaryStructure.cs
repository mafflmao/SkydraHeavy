namespace LibSkydra
{
    public class shaderBinaryStructure : igObject 
    {
        public shaderBinaryStructure(IGZ igz) : base(igz) { } 
    }
}
