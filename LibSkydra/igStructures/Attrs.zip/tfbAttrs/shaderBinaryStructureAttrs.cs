namespace LibSkydra
{
    public class shaderBinaryStructureAttrs : igObject 
    {
        public shaderBinaryStructureAttrs(IGZ igz) : base(igz) { } 
    }
}
