namespace LibSkydra
{
    public class simple_PS : igObject 
    {
        public simple_PS(IGZ igz) : base(igz) { } 
    }
}
