namespace LibSkydra
{
    public class simple_VS : igObject 
    {
        public simple_VS(IGZ igz) : base(igz) { } 
    }
}
