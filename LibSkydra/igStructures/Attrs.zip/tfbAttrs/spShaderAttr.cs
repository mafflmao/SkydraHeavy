namespace LibSkydra
{
    public class spShaderAttr : igObject 
    {
        public spShaderAttr(IGZ igz) : base(igz) { } 
    }
}
