namespace LibSkydra
{
    public class spriteText_PS : igObject 
    {
        public spriteText_PS(IGZ igz) : base(igz) { } 
    }
}
