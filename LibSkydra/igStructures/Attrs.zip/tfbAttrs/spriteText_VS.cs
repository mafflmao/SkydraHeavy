namespace LibSkydra
{
    public class spriteText_VS : igObject 
    {
        public spriteText_VS(IGZ igz) : base(igz) { } 
    }
}
