namespace LibSkydra
{
    public class textureColorPS : igObject 
    {
        public textureColorPS(IGZ igz) : base(igz) { } 
    }
}
