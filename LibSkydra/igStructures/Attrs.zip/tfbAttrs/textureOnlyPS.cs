namespace LibSkydra
{
    public class textureOnlyPS : igObject 
    {
        public textureOnlyPS(IGZ igz) : base(igz) { } 
    }
}
