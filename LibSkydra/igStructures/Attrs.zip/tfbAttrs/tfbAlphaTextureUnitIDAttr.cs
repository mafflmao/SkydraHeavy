// It's impossible to know what namespace this is under currently so i'm assuming tfbAttr cos of tfbTextureBindAttr
namespace LibSkydra
{
	//TODO: Double check for SSA Wii
	public class tfbAlphaTextureUnitIDAttr : igObject
	{
		[igObjectRefMetaField(0x06, IG_CORE_PLATFORM.DEFAULT, "_alphaTexture", 0x10)]		//Apparently the actual offset is 0x18 but this is incorrect??
		public igTextureAttr2 alphaTexture;

		[igIntMetaField(0x06, IG_CORE_PLATFORM.DEFAULT, "_data", 0x1C)]						//Since the previous metafield has the incorrect offset idrk what's going on here
		public int data;

		[igIntMetaField(0x06, IG_CORE_PLATFORM.DEFAULT, "_handle", 0xFFFF)]
		public int handle;

		[igObjectRefMetaField(0x06, IG_CORE_PLATFORM.DEFAULT, "_alphaTextureUnitIDForColorTextureList", 0xFFFF)]
		public igObject _alphaTextureUnitIDForColorTextureList;

		public tfbAlphaTextureUnitIDAttr(IGZ parent) : base(parent){}
	}
}