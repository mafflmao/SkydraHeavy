namespace LibSkydra
{
    public class tfbCommonTraversal : igObject 
    {
        public tfbCommonTraversal(IGZ igz) : base(igz) { } 
    }
}
