namespace LibSkydra
{
    public class tfbDestinationAlphaAttr : igObject 
    {
        public tfbDestinationAlphaAttr(IGZ igz) : base(igz) { } 
    }
}
