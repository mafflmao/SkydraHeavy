namespace LibSkydra
{
    public class tfbEffectInfo : igObject 
    {
        public tfbEffectInfo(IGZ igz) : base(igz) { } 
    }
}
