namespace LibSkydra
{
    public class tfbEnvironmentMapTextureMatrixAttr : igObject 
    {
        public tfbEnvironmentMapTextureMatrixAttr(IGZ igz) : base(igz) { } 
    }
}
