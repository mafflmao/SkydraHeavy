namespace LibSkydra
{
    public class tfbFlipBookUVAnimData : igObject 
    {
        public tfbFlipBookUVAnimData(IGZ igz) : base(igz) { } 
    }
}
