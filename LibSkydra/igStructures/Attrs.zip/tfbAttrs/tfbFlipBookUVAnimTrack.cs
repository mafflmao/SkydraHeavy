namespace LibSkydra
{
    public class tfbFlipBookUVAnimTrack : igObject 
    {
        public tfbFlipBookUVAnimTrack(IGZ igz) : base(igz) { } 
    }
}
