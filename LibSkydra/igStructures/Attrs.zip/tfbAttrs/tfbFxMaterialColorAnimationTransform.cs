namespace LibSkydra
{
    public class tfbFxMaterialColorAnimationTransform : igObject 
    {
        public tfbFxMaterialColorAnimationTransform(IGZ igz) : base(igz) { } 
    }
}
