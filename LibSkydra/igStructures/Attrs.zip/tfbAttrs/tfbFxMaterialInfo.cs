namespace LibSkydra
{
    public class tfbFxMaterialInfo : igObject 
    {
        public tfbFxMaterialInfo(IGZ igz) : base(igz) { } 
    }
}
