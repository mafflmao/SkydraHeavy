namespace LibSkydra
{
    public class tfbFxMaterialUvAnimationTransform : igObject 
    {
        public tfbFxMaterialUvAnimationTransform(IGZ igz) : base(igz) { } 
    }
}
