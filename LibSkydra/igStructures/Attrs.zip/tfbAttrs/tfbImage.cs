namespace LibSkydra
{
    public class tfbImage : igObject 
    {
        public tfbImage(IGZ igz) : base(igz) { } 
    }
}
