namespace LibSkydra
{
    public class tfbInvertAlphaAttr : igObject 
    {
        public tfbInvertAlphaAttr(IGZ igz) : base(igz) { } 
    }
}
