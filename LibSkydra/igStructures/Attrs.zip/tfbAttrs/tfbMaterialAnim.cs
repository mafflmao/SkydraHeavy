namespace LibSkydra
{
    public class tfbMaterialAnim : igObject 
    {
        public tfbMaterialAnim(IGZ igz) : base(igz) { } 
    }
}
