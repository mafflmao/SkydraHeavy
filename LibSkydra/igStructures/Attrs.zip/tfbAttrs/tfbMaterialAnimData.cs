namespace LibSkydra
{
    public class tfbMaterialAnimData : igObject 
    {
        public tfbMaterialAnimData(IGZ igz) : base(igz) { } 
    }
}
