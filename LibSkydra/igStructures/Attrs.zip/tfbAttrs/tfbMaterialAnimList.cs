namespace LibSkydra
{
    public class tfbMaterialAnimList : igObject 
    {
        public tfbMaterialAnimList(IGZ igz) : base(igz) { } 
    }
}
