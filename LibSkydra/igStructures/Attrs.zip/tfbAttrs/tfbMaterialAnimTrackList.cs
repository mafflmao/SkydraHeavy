namespace LibSkydra
{
    public class tfbMaterialAnimTrackList : igObject 
    {
        public tfbMaterialAnimTrackList(IGZ igz) : base(igz) { } 
    }
}
