namespace LibSkydra
{
    public class tfbMaterialTintAnimTrack : igObject 
    {
        public tfbMaterialTintAnimTrack(IGZ igz) : base(igz) { } 
    }
}
