namespace LibSkydra
{
    public class tfbMaterialUVAnimData : igObject 
    {
        public tfbMaterialUVAnimData(IGZ igz) : base(igz) { } 
    }
}
