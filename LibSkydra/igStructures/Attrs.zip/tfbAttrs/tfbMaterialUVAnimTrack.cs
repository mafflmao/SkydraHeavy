namespace LibSkydra
{
    public class tfbMaterialUVAnimTrack : igObject 
    {
        public tfbMaterialUVAnimTrack(IGZ igz) : base(igz) { } 
    }
}
