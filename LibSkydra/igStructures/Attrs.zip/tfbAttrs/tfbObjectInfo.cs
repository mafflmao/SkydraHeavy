namespace LibSkydra
{
    public class tfbObjectInfo : igObject 
    {
        public tfbObjectInfo(IGZ igz) : base(igz) { } 
    }
}
