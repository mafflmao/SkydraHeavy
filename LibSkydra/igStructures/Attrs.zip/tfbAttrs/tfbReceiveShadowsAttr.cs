namespace LibSkydra
{
    public class tfbReceiveShadowsAttr : igObject 
    {
        public tfbReceiveShadowsAttr(IGZ igz) : base(igz) { } 
    }
}
