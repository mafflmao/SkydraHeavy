namespace LibSkydra
{
    public class tfbScrollUVAnimData : igObject 
    {
        public tfbScrollUVAnimData(IGZ igz) : base(igz) { } 
    }
}
