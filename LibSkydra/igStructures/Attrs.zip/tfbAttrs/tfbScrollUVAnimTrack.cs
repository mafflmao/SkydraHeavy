namespace LibSkydra
{
    public class tfbScrollUVAnimTrack : igObject 
    {
        public tfbScrollUVAnimTrack(IGZ igz) : base(igz) { } 
    }
}
