namespace LibSkydra
{
    public class tfbShaderAttr : igObject 
    {
        public tfbShaderAttr(IGZ igz) : base(igz) { } 
    }
}
