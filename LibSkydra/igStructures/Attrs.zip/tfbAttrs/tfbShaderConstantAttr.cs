namespace LibSkydra
{
    public class tfbShaderConstantAttr : igObject 
    {
        public tfbShaderConstantAttr(IGZ igz) : base(igz) { } 
    }
}
