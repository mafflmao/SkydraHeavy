namespace LibSkydra
{
    public class tfbShaderConstantBoolAttr : igObject 
    {
        public tfbShaderConstantBoolAttr(IGZ igz) : base(igz) { } 
    }
}
