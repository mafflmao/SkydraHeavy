namespace LibSkydra
{
    public class tfbShaderConstantFloatAttr : igObject 
    {
        public tfbShaderConstantFloatAttr(IGZ igz) : base(igz) { } 
    }
}
