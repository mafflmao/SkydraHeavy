namespace LibSkydra
{
    public class tfbShaderConstantIntAttr : igObject 
    {
        public tfbShaderConstantIntAttr(IGZ igz) : base(igz) { } 
    }
}
