namespace LibSkydra
{
    public class tfbShaderConstantMatrix44fAttr : igObject 
    {
        public tfbShaderConstantMatrix44fAttr(IGZ igz) : base(igz) { } 
    }
}
