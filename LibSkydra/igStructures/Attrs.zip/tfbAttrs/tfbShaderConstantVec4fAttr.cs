namespace LibSkydra
{
    public class tfbShaderConstantVec4fAttr : igObject 
    {
        public tfbShaderConstantVec4fAttr(IGZ igz) : base(igz) { } 
    }
}
