namespace LibSkydra
{
    public class tfbShaders : igObject 
    {
        public tfbShaders(IGZ igz) : base(igz) { } 
    }
}
