namespace LibSkydra
{
    public class tfbShadowCastingBufferIndexAttr : igObject 
    {
        public tfbShadowCastingBufferIndexAttr(IGZ igz) : base(igz) { } 
    }
}
