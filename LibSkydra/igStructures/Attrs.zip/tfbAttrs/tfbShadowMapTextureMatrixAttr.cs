namespace LibSkydra
{
    public class tfbShadowMapTextureMatrixAttr : igObject 
    {
        public tfbShadowMapTextureMatrixAttr(IGZ igz) : base(igz) { } 
    }
}
