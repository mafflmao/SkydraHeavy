namespace LibSkydra
{
    public class tfbSpShaders : igObject 
    {
        public tfbSpShaders(IGZ igz) : base(igz) { } 
    }
}
