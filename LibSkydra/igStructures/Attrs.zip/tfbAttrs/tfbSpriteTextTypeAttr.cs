namespace LibSkydra
{
    public class tfbSpriteTextTypeAttr : igObject 
    {
        public tfbSpriteTextTypeAttr(IGZ igz) : base(igz) { } 
    }
}
