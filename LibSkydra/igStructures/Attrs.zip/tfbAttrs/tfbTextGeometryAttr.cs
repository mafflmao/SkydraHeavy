namespace LibSkydra
{
    public class tfbTextGeometryAttr : igObject 
    {
        public tfbTextGeometryAttr(IGZ igz) : base(igz) { } 
    }
}
