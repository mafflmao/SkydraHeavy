namespace LibSkydra
{
	//this is literally a tfbAlphaTextureUnitIDAttr
	public class tfbTextureBindAttr : igObject
	{
		[igObjectRefMetaField(0x08, IG_CORE_PLATFORM.DEFAULT, "_alphaTexture", 0x10)]		//Apparently the actual offset is 0x18 but this is incorrect??
		public igTextureAttr2 alphaTexture;

		[igIntMetaField(0x08, IG_CORE_PLATFORM.DEFAULT, "_data", 0x1C)]						//Since the previous metafield has the incorrect offset idrk what's going on here
		public int data;

		[igTStaticMetaField(0x08, IG_CORE_PLATFORM.DEFAULT, "_handle", 0xFFFF)]
		public static int handle;

		[igTStaticMetaField(0x08, IG_CORE_PLATFORM.DEFAULT, "_alphaTextureUnitIDForColorTextureList", 0xFFFF)]
		public static igObject _alphaTextureUnitIDForColorTextureList;

		public tfbTextureBindAttr(IGZ parent) : base(parent){}
	}
}