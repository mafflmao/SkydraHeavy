namespace LibSkydra
{
    public class tfbTransformUVAnimData : igObject 
    {
        public tfbTransformUVAnimData(IGZ igz) : base(igz) { } 
    }
}
