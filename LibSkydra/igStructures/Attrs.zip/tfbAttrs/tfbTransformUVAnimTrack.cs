namespace LibSkydra
{
    public class tfbTransformUVAnimTrack : igObject 
    {
        public tfbTransformUVAnimTrack(IGZ igz) : base(igz) { } 
    }
}
