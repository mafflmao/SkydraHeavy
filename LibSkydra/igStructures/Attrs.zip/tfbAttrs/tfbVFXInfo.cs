namespace LibSkydra
{
    public class tfbVFXInfo : igObject 
    {
        public tfbVFXInfo(IGZ igz) : base(igz) { } 
    }
}
