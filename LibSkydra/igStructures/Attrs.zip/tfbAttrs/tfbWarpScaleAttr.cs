namespace LibSkydra
{
    public class tfbWarpScaleAttr : igObject 
    {
        public tfbWarpScaleAttr(IGZ igz) : base(igz) { } 
    }
}
