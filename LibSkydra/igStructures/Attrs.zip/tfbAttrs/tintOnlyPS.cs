namespace LibSkydra
{
    public class tintOnlyPS : igObject 
    {
        public tintOnlyPS(IGZ igz) : base(igz) { } 
    }
}
