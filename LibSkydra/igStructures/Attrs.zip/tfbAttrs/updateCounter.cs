namespace LibSkydra
{
    public class updateCounter : igObject 
    {
        public updateCounter(IGZ igz) : base(igz) { } 
    }
}
