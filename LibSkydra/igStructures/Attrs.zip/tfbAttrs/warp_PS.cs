namespace LibSkydra
{
    public class warp_PS : igObject 
    {
        public warp_PS(IGZ igz) : base(igz) { } 
    }
}
