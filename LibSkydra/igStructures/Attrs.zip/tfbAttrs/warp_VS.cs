namespace LibSkydra
{
    public class warp_VS : igObject 
    {
        public warp_VS(IGZ igz) : base(igz) { } 
    }
}
