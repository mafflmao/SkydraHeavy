namespace LibSkydra
{
    public class BedrockDataWritingCallbackintvoidunsignedint : igObject 
    {
        public BedrockDataWritingCallbackintvoidunsignedint(IGZ igz) : base(igz) { } 
    }
}
