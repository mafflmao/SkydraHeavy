namespace LibSkydra
{
    public class BedrockEventCallback_brEventTypevoidvoid : igObject 
    {
        public BedrockEventCallback_brEventTypevoidvoid(IGZ igz) : base(igz) { } 
    }
}
