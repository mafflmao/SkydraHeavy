namespace LibSkydra
{
    public class alignedAllocateFuncunsignedlongunsignedlong : igObject 
    {
        public alignedAllocateFuncunsignedlongunsignedlong(IGZ igz) : base(igz) { } 
    }
}
