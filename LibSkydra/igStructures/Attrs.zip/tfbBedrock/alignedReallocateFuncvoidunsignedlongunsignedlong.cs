namespace LibSkydra
{
    public class alignedReallocateFuncvoidunsignedlongunsignedlong : igObject 
    {
        public alignedReallocateFuncvoidunsignedlongunsignedlong(IGZ igz) : base(igz) { } 
    }
}
