namespace LibSkydra
{
    public class allocateFuncunsignedlong : igObject 
    {
        public allocateFuncunsignedlong(IGZ igz) : base(igz) { } 
    }
}
