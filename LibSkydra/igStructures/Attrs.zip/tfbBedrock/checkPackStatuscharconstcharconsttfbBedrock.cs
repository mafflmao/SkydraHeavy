namespace LibSkydra
{
    public class checkPackStatuscharconstcharconsttfbBedrock : igObject 
    {
        public checkPackStatuscharconstcharconsttfbBedrock(IGZ igz) : base(igz) { } 
    }
}
