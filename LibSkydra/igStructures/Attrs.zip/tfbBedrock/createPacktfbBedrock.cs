namespace LibSkydra
{
    public class createPacktfbBedrock : igObject 
    {
        public createPacktfbBedrock(IGZ igz) : base(igz) { } 
    }
}
