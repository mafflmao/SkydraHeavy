namespace LibSkydra
{
    public class deallocateFuncvoid : igObject 
    {
        public deallocateFuncvoid(IGZ igz) : base(igz) { } 
    }
}
