namespace LibSkydra
{
    public class downloadFilesFromPacktfbBedrock : igObject 
    {
        public downloadFilesFromPacktfbBedrock(IGZ igz) : base(igz) { } 
    }
}
