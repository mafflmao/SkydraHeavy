namespace LibSkydra
{
    public class getPool : igObject 
    {
        public getPool(IGZ igz) : base(igz) { } 
    }
}
