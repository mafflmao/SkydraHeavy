namespace LibSkydra
{
    public class getReserveStorageDirectoryCore : igObject 
    {
        public getReserveStorageDirectoryCore(IGZ igz) : base(igz) { } 
    }
}
