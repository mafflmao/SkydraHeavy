namespace LibSkydra
{
    public class gettfbDownloadFileStatusMetaEnum : igObject 
    {
        public gettfbDownloadFileStatusMetaEnum(IGZ igz) : base(igz) { } 
    }
}
