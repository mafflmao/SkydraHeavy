namespace LibSkydra
{
    public class gettfbReservationModeMetaEnum : igObject 
    {
        public gettfbReservationModeMetaEnum(IGZ igz) : base(igz) { } 
    }
}
