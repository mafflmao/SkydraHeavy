namespace LibSkydra
{
    public class gettfbReservedSpaceStatusMetaEnum : igObject 
    {
        public gettfbReservedSpaceStatusMetaEnum(IGZ igz) : base(igz) { } 
    }
}
