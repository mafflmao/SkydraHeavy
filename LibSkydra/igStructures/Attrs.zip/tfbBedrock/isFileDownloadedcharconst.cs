namespace LibSkydra
{
    public class isFileDownloadedcharconst : igObject 
    {
        public isFileDownloadedcharconst(IGZ igz) : base(igz) { } 
    }
}
