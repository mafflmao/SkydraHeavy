namespace LibSkydra
{
    public class isReserveReady : igObject 
    {
        public isReserveReady(IGZ igz) : base(igz) { } 
    }
}
