namespace LibSkydra
{
    public class productIdentifiers : igObject 
    {
        public productIdentifiers(IGZ igz) : base(igz) { } 
    }
}
