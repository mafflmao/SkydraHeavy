namespace LibSkydra
{
    public class reallocateFuncvoidunsignedlong : igObject 
    {
        public reallocateFuncvoidunsignedlong(IGZ igz) : base(igz) { } 
    }
}
