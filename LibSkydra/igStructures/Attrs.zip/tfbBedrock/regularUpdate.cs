namespace LibSkydra
{
    public class regularUpdate : igObject 
    {
        public regularUpdate(IGZ igz) : base(igz) { } 
    }
}
