namespace LibSkydra
{
    public class reserveSpacevoid : igObject 
    {
        public reserveSpacevoid(IGZ igz) : base(igz) { } 
    }
}
