namespace LibSkydra
{
    public class sTfbBedrockMemoryPool : igObject 
    {
        public sTfbBedrockMemoryPool(IGZ igz) : base(igz) { } 
    }
}
