namespace LibSkydra
{
    public class scopeTimer : igObject 
    {
        public scopeTimer(IGZ igz) : base(igz) { } 
    }
}
