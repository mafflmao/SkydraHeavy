namespace LibSkydra
{
    public class sizeOfDirectoryBigEnoughcharconstlonglong : igObject 
    {
        public sizeOfDirectoryBigEnoughcharconstlonglong(IGZ igz) : base(igz) { } 
    }
}
