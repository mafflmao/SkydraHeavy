namespace LibSkydra
{
    public class sortStatItemsByTimestamptfbBedrock : igObject 
    {
        public sortStatItemsByTimestamptfbBedrock(IGZ igz) : base(igz) { } 
    }
}
