namespace LibSkydra
{
    public class start : igObject 
    {
        public start(IGZ igz) : base(igz) { } 
    }
}
