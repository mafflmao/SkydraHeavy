namespace LibSkydra
{
    public class tfbAllFilesDownloadedState : igObject 
    {
        public tfbAllFilesDownloadedState(IGZ igz) : base(igz) { } 
    }
}
