namespace LibSkydra
{
    public class tfbBaseCondition : igObject 
    {
        public tfbBaseCondition(IGZ igz) : base(igz) { } 
    }
}
