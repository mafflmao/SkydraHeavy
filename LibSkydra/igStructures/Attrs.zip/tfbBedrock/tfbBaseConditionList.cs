namespace LibSkydra
{
    public class tfbBaseConditionList : igObject 
    {
        public tfbBaseConditionList(IGZ igz) : base(igz) { } 
    }
}
