namespace LibSkydra
{
    public class tfbBaseState : igObject 
    {
        public tfbBaseState(IGZ igz) : base(igz) { } 
    }
}
