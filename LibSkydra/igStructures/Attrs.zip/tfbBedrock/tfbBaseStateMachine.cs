namespace LibSkydra
{
    public class tfbBaseStateMachine : igObject 
    {
        public tfbBaseStateMachine(IGZ igz) : base(igz) { } 
    }
}
