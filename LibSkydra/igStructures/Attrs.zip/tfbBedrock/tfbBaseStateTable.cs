namespace LibSkydra
{
    public class tfbBaseStateTable : igObject 
    {
        public tfbBaseStateTable(IGZ igz) : base(igz) { } 
    }
}
