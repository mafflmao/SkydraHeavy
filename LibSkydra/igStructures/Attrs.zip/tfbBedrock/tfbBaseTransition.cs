namespace LibSkydra
{
    public class tfbBaseTransition : igObject 
    {
        public tfbBaseTransition(IGZ igz) : base(igz) { } 
    }
}
