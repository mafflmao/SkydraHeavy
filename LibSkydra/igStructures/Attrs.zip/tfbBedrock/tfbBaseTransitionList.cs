namespace LibSkydra
{
    public class tfbBaseTransitionList : igObject 
    {
        public tfbBaseTransitionList(IGZ igz) : base(igz) { } 
    }
}
