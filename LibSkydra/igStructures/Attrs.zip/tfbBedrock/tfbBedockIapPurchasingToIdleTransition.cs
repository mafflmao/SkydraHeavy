namespace LibSkydra
{
    public class tfbBedockIapPurchasingToIdleTransition : igObject 
    {
        public tfbBedockIapPurchasingToIdleTransition(IGZ igz) : base(igz) { } 
    }
}
