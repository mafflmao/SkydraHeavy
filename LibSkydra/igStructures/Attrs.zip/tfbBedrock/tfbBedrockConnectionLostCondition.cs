namespace LibSkydra
{
    public class tfbBedrockConnectionLostCondition : igObject 
    {
        public tfbBedrockConnectionLostCondition(IGZ igz) : base(igz) { } 
    }
}
