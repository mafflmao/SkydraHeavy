namespace LibSkydra
{
    public class tfbBedrockIapCheckPurchaseToIdleTransition : igObject 
    {
        public tfbBedrockIapCheckPurchaseToIdleTransition(IGZ igz) : base(igz) { } 
    }
}
