namespace LibSkydra
{
    public class tfbBedrockIapCheckPurchasesState : igObject 
    {
        public tfbBedrockIapCheckPurchasesState(IGZ igz) : base(igz) { } 
    }
}
