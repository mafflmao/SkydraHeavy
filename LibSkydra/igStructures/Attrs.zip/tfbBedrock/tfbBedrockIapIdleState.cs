namespace LibSkydra
{
    public class tfbBedrockIapIdleState : igObject 
    {
        public tfbBedrockIapIdleState(IGZ igz) : base(igz) { } 
    }
}
