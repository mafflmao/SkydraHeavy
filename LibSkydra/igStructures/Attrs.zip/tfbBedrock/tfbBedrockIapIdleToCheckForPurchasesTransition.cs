namespace LibSkydra
{
    public class tfbBedrockIapIdleToCheckForPurchasesTransition : igObject 
    {
        public tfbBedrockIapIdleToCheckForPurchasesTransition(IGZ igz) : base(igz) { } 
    }
}
