namespace LibSkydra
{
    public class tfbBedrockIapIdleToPurchasingTransition : igObject 
    {
        public tfbBedrockIapIdleToPurchasingTransition(IGZ igz) : base(igz) { } 
    }
}
