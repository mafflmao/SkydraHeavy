namespace LibSkydra
{
    public class tfbBedrockIapInitializeCatalogState : igObject 
    {
        public tfbBedrockIapInitializeCatalogState(IGZ igz) : base(igz) { } 
    }
}
