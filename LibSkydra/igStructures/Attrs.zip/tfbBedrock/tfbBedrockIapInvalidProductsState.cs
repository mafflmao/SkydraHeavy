namespace LibSkydra
{
    public class tfbBedrockIapInvalidProductsState : igObject 
    {
        public tfbBedrockIapInvalidProductsState(IGZ igz) : base(igz) { } 
    }
}
