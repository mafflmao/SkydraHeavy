namespace LibSkydra
{
    public class tfbBedrockIapIsReadyForIapCondition : igObject 
    {
        public tfbBedrockIapIsReadyForIapCondition(IGZ igz) : base(igz) { } 
    }
}
