namespace LibSkydra
{
    public class tfbBedrockIapPurchasingState : igObject 
    {
        public tfbBedrockIapPurchasingState(IGZ igz) : base(igz) { } 
    }
}
