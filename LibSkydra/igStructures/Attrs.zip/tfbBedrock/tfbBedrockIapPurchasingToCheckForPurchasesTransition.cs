namespace LibSkydra
{
    public class tfbBedrockIapPurchasingToCheckForPurchasesTransition : igObject 
    {
        public tfbBedrockIapPurchasingToCheckForPurchasesTransition(IGZ igz) : base(igz) { } 
    }
}
