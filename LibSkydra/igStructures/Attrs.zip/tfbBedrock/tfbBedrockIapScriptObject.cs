namespace LibSkydra
{
    public class tfbBedrockIapScriptObject : igObject 
    {
        public tfbBedrockIapScriptObject(IGZ igz) : base(igz) { } 
    }
}
