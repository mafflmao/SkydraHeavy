namespace LibSkydra
{
    public class tfbBedrockIapStateMachine : igObject 
    {
        public tfbBedrockIapStateMachine(IGZ igz) : base(igz) { } 
    }
}
