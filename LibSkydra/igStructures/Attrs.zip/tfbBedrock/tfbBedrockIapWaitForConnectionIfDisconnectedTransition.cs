namespace LibSkydra
{
    public class tfbBedrockIapWaitForConnectionIfDisconnectedTransition : igObject 
    {
        public tfbBedrockIapWaitForConnectionIfDisconnectedTransition(IGZ igz) : base(igz) { } 
    }
}
