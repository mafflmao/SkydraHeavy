namespace LibSkydra
{
    public class tfbBedrockIapWaitForConnectionState : igObject 
    {
        public tfbBedrockIapWaitForConnectionState(IGZ igz) : base(igz) { } 
    }
}
