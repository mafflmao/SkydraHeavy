namespace LibSkydra
{
    public class tfbBedrockIapWaitForConnectionToInitializeCatalogTransition : igObject 
    {
        public tfbBedrockIapWaitForConnectionToInitializeCatalogTransition(IGZ igz) : base(igz) { } 
    }
}
