namespace LibSkydra
{
    public class tfbBedrockManager : igObject 
    {
        public tfbBedrockManager(IGZ igz) : base(igz) { } 
    }
}
