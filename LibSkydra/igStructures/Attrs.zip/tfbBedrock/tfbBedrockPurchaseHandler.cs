namespace LibSkydra
{
    public class tfbBedrockPurchaseHandler : igObject 
    {
        public tfbBedrockPurchaseHandler(IGZ igz) : base(igz) { } 
    }
}
