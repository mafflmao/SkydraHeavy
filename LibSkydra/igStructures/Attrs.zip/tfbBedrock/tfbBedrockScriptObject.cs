namespace LibSkydra
{
    public class tfbBedrockScriptObject : igObject 
    {
        public tfbBedrockScriptObject(IGZ igz) : base(igz) { } 
    }
}
