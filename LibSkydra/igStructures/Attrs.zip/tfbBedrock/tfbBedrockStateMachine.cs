namespace LibSkydra
{
    public class tfbBedrockStateMachine : igObject 
    {
        public tfbBedrockStateMachine(IGZ igz) : base(igz) { } 
    }
}
