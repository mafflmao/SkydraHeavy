namespace LibSkydra
{
    public class tfbCheckFileRequestedCondition : igObject 
    {
        public tfbCheckFileRequestedCondition(IGZ igz) : base(igz) { } 
    }
}
