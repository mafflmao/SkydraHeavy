namespace LibSkydra
{
    public class tfbConnectionDroppedState : igObject 
    {
        public tfbConnectionDroppedState(IGZ igz) : base(igz) { } 
    }
}
