namespace LibSkydra
{
    public class tfbDisconnectTransition : igObject 
    {
        public tfbDisconnectTransition(IGZ igz) : base(igz) { } 
    }
}
