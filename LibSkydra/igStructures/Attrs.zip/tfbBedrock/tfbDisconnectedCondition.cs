namespace LibSkydra
{
    public class tfbDisconnectedCondition : igObject 
    {
        public tfbDisconnectedCondition(IGZ igz) : base(igz) { } 
    }
}
