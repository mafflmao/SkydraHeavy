namespace LibSkydra
{
    public class tfbDownloadCompleteCondition : igObject 
    {
        public tfbDownloadCompleteCondition(IGZ igz) : base(igz) { } 
    }
}
