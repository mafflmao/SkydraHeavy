namespace LibSkydra
{
    public class tfbDownloadCompleteReserveDepletedCondition : igObject 
    {
        public tfbDownloadCompleteReserveDepletedCondition(IGZ igz) : base(igz) { } 
    }
}
