namespace LibSkydra
{
    public class tfbDownloadCompleteReserveDepletedTransition : igObject 
    {
        public tfbDownloadCompleteReserveDepletedTransition(IGZ igz) : base(igz) { } 
    }
}
