namespace LibSkydra
{
    public class tfbDownloadCompleteTransition : igObject 
    {
        public tfbDownloadCompleteTransition(IGZ igz) : base(igz) { } 
    }
}
