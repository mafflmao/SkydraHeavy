namespace LibSkydra
{
    public class tfbDownloadFileItem : igObject 
    {
        public tfbDownloadFileItem(IGZ igz) : base(igz) { } 
    }
}
