namespace LibSkydra
{
    public class tfbDownloadFileItemList : igObject 
    {
        public tfbDownloadFileItemList(IGZ igz) : base(igz) { } 
    }
}
