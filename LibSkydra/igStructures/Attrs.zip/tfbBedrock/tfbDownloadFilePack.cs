namespace LibSkydra
{
    public class tfbDownloadFilePack : igObject 
    {
        public tfbDownloadFilePack(IGZ igz) : base(igz) { } 
    }
}
