namespace LibSkydra
{
    public class tfbDownloadFilePackList : igObject 
    {
        public tfbDownloadFilePackList(IGZ igz) : base(igz) { } 
    }
}
