namespace LibSkydra
{
    public class tfbDownloadFileStatus_Meta : igObject 
    {
        public tfbDownloadFileStatus_Meta(IGZ igz) : base(igz) { } 
    }
}
