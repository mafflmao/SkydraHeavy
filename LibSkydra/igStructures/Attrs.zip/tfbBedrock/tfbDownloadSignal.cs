namespace LibSkydra
{
    public class tfbDownloadSignal : igObject 
    {
        public tfbDownloadSignal(IGZ igz) : base(igz) { } 
    }
}
