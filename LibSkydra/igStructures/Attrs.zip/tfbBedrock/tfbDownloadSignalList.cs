namespace LibSkydra
{
    public class tfbDownloadSignalList : igObject 
    {
        public tfbDownloadSignalList(IGZ igz) : base(igz) { } 
    }
}
