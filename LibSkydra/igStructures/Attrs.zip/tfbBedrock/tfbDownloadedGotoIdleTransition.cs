namespace LibSkydra
{
    public class tfbDownloadedGotoIdleTransition : igObject 
    {
        public tfbDownloadedGotoIdleTransition(IGZ igz) : base(igz) { } 
    }
}
