namespace LibSkydra
{
    public class tfbDownloadedTransition : igObject 
    {
        public tfbDownloadedTransition(IGZ igz) : base(igz) { } 
    }
}
