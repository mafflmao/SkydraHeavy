namespace LibSkydra
{
    public class tfbDownloadingFileState : igObject 
    {
        public tfbDownloadingFileState(IGZ igz) : base(igz) { } 
    }
}
