namespace LibSkydra
{
    public class tfbDroppedToDownloadFileTransition : igObject 
    {
        public tfbDroppedToDownloadFileTransition(IGZ igz) : base(igz) { } 
    }
}
