namespace LibSkydra
{
    public class tfbFileDownloadedCondition : igObject 
    {
        public tfbFileDownloadedCondition(IGZ igz) : base(igz) { } 
    }
}
