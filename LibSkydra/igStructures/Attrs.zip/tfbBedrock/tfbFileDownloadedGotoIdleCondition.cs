namespace LibSkydra
{
    public class tfbFileDownloadedGotoIdleCondition : igObject 
    {
        public tfbFileDownloadedGotoIdleCondition(IGZ igz) : base(igz) { } 
    }
}
