namespace LibSkydra
{
    public class tfbFileItemStats : igObject 
    {
        public tfbFileItemStats(IGZ igz) : base(igz) { } 
    }
}
