namespace LibSkydra
{
    public class tfbFileItemStatsList : igObject 
    {
        public tfbFileItemStatsList(IGZ igz) : base(igz) { } 
    }
}
