namespace LibSkydra
{
    public class tfbFileRequestedTransition : igObject 
    {
        public tfbFileRequestedTransition(IGZ igz) : base(igz) { } 
    }
}
