namespace LibSkydra
{
    public class tfbIapBaseState : igObject 
    {
        public tfbIapBaseState(IGZ igz) : base(igz) { } 
    }
}
