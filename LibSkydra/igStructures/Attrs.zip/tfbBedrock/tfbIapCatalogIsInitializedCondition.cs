namespace LibSkydra
{
    public class tfbIapCatalogIsInitializedCondition : igObject 
    {
        public tfbIapCatalogIsInitializedCondition(IGZ igz) : base(igz) { } 
    }
}
