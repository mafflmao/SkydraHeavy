namespace LibSkydra
{
    public class tfbIapRetryProductInitializationTransition : igObject 
    {
        public tfbIapRetryProductInitializationTransition(IGZ igz) : base(igz) { } 
    }
}
