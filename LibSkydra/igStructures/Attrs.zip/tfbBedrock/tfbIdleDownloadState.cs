namespace LibSkydra
{
    public class tfbIdleDownloadState : igObject 
    {
        public tfbIdleDownloadState(IGZ igz) : base(igz) { } 
    }
}
