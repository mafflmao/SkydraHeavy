namespace LibSkydra
{
    public class tfbIdleToDownloadingFileCondition : igObject 
    {
        public tfbIdleToDownloadingFileCondition(IGZ igz) : base(igz) { } 
    }
}
