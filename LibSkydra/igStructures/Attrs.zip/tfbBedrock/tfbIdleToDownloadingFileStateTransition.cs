namespace LibSkydra
{
    public class tfbIdleToDownloadingFileStateTransition : igObject 
    {
        public tfbIdleToDownloadingFileStateTransition(IGZ igz) : base(igz) { } 
    }
}
