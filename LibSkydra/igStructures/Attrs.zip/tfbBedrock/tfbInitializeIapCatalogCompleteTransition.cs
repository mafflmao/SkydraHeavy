namespace LibSkydra
{
    public class tfbInitializeIapCatalogCompleteTransition : igObject 
    {
        public tfbInitializeIapCatalogCompleteTransition(IGZ igz) : base(igz) { } 
    }
}
