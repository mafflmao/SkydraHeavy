namespace LibSkydra
{
    public class tfbIsBedrockConnectedCondition : igObject 
    {
        public tfbIsBedrockConnectedCondition(IGZ igz) : base(igz) { } 
    }
}
