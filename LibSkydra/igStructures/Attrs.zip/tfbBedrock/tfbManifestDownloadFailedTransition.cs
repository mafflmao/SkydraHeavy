namespace LibSkydra
{
    public class tfbManifestDownloadFailedTransition : igObject 
    {
        public tfbManifestDownloadFailedTransition(IGZ igz) : base(igz) { } 
    }
}
