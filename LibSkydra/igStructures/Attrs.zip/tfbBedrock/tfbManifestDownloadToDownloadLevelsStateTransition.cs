namespace LibSkydra
{
    public class tfbManifestDownloadToDownloadLevelsStateTransition : igObject 
    {
        public tfbManifestDownloadToDownloadLevelsStateTransition(IGZ igz) : base(igz) { } 
    }
}
