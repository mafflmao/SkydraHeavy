namespace LibSkydra
{
    public class tfbManifestDownloadToReserveDepletedTransition : igObject 
    {
        public tfbManifestDownloadToReserveDepletedTransition(IGZ igz) : base(igz) { } 
    }
}
