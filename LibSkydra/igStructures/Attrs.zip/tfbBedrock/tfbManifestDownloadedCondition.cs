namespace LibSkydra
{
    public class tfbManifestDownloadedCondition : igObject 
    {
        public tfbManifestDownloadedCondition(IGZ igz) : base(igz) { } 
    }
}
