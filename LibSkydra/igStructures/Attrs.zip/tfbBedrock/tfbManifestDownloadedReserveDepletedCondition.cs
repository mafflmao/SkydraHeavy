namespace LibSkydra
{
    public class tfbManifestDownloadedReserveDepletedCondition : igObject 
    {
        public tfbManifestDownloadedReserveDepletedCondition(IGZ igz) : base(igz) { } 
    }
}
