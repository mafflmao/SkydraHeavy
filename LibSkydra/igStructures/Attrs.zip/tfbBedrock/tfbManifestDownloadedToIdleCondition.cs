namespace LibSkydra
{
    public class tfbManifestDownloadedToIdleCondition : igObject 
    {
        public tfbManifestDownloadedToIdleCondition(IGZ igz) : base(igz) { } 
    }
}
