namespace LibSkydra
{
    public class tfbManifestDownloadedToIdleTransition : igObject 
    {
        public tfbManifestDownloadedToIdleTransition(IGZ igz) : base(igz) { } 
    }
}
