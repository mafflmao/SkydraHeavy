namespace LibSkydra
{
    public class tfbRequestDownloadPackState : igObject 
    {
        public tfbRequestDownloadPackState(IGZ igz) : base(igz) { } 
    }
}
