namespace LibSkydra
{
    public class tfbRequestedFileDownloadCompleteCondition : igObject 
    {
        public tfbRequestedFileDownloadCompleteCondition(IGZ igz) : base(igz) { } 
    }
}
