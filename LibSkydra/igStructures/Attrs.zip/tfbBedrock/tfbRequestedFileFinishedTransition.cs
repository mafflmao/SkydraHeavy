namespace LibSkydra
{
    public class tfbRequestedFileFinishedTransition : igObject 
    {
        public tfbRequestedFileFinishedTransition(IGZ igz) : base(igz) { } 
    }
}
