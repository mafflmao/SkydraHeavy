namespace LibSkydra
{
    public class tfbRequestedPackCompletedCondition : igObject 
    {
        public tfbRequestedPackCompletedCondition(IGZ igz) : base(igz) { } 
    }
}
