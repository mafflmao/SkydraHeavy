namespace LibSkydra
{
    public class tfbRequestedPackCompletedReserveDepletedCondition : igObject 
    {
        public tfbRequestedPackCompletedReserveDepletedCondition(IGZ igz) : base(igz) { } 
    }
}
