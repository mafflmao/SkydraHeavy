namespace LibSkydra
{
    public class tfbRequestedPackCompletedReserveDepletedTransition : igObject 
    {
        public tfbRequestedPackCompletedReserveDepletedTransition(IGZ igz) : base(igz) { } 
    }
}
