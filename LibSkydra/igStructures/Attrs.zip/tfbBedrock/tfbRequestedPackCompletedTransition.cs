namespace LibSkydra
{
    public class tfbRequestedPackCompletedTransition : igObject 
    {
        public tfbRequestedPackCompletedTransition(IGZ igz) : base(igz) { } 
    }
}
