namespace LibSkydra
{
    public class tfbRequestedPackDownloadedToIdleCondition : igObject 
    {
        public tfbRequestedPackDownloadedToIdleCondition(IGZ igz) : base(igz) { } 
    }
}
