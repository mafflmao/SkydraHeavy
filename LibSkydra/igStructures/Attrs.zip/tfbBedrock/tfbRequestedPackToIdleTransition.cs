namespace LibSkydra
{
    public class tfbRequestedPackToIdleTransition : igObject 
    {
        public tfbRequestedPackToIdleTransition(IGZ igz) : base(igz) { } 
    }
}
