namespace LibSkydra
{
    public class tfbReservationMode_Meta : igObject 
    {
        public tfbReservationMode_Meta(IGZ igz) : base(igz) { } 
    }
}
