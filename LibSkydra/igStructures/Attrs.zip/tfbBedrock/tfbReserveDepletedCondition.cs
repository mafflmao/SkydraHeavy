namespace LibSkydra
{
    public class tfbReserveDepletedCondition : igObject 
    {
        public tfbReserveDepletedCondition(IGZ igz) : base(igz) { } 
    }
}
