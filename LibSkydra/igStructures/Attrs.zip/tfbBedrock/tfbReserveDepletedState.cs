namespace LibSkydra
{
    public class tfbReserveDepletedState : igObject 
    {
        public tfbReserveDepletedState(IGZ igz) : base(igz) { } 
    }
}
