namespace LibSkydra
{
    public class tfbReserveDepletedTransition : igObject 
    {
        public tfbReserveDepletedTransition(IGZ igz) : base(igz) { } 
    }
}
