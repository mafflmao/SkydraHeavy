namespace LibSkydra
{
    public class tfbReservedSpaceStatus_Meta : igObject 
    {
        public tfbReservedSpaceStatus_Meta(IGZ igz) : base(igz) { } 
    }
}
