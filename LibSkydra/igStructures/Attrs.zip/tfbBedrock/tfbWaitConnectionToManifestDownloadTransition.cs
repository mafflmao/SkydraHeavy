namespace LibSkydra
{
    public class tfbWaitConnectionToManifestDownloadTransition : igObject 
    {
        public tfbWaitConnectionToManifestDownloadTransition(IGZ igz) : base(igz) { } 
    }
}
