namespace LibSkydra
{
    public class tfbWaitForBedrockConnectionState : igObject 
    {
        public tfbWaitForBedrockConnectionState(IGZ igz) : base(igz) { } 
    }
}
