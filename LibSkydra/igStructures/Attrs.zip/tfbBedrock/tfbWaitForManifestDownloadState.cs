namespace LibSkydra
{
    public class tfbWaitForManifestDownloadState : igObject 
    {
        public tfbWaitForManifestDownloadState(IGZ igz) : base(igz) { } 
    }
}
