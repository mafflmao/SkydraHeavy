namespace LibSkydra
{
    public class tfbWaitForSignalCondition : igObject 
    {
        public tfbWaitForSignalCondition(IGZ igz) : base(igz) { } 
    }
}
