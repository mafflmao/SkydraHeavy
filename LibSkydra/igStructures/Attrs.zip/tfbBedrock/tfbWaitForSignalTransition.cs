namespace LibSkydra
{
    public class tfbWaitForSignalTransition : igObject 
    {
        public tfbWaitForSignalTransition(IGZ igz) : base(igz) { } 
    }
}
