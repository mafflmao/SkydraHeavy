namespace LibSkydra
{
    public class threadUpdatevoid : igObject 
    {
        public threadUpdatevoid(IGZ igz) : base(igz) { } 
    }
}
