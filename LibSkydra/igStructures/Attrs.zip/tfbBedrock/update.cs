namespace LibSkydra
{
    public class update : igObject 
    {
        public update(IGZ igz) : base(igz) { } 
    }
}
