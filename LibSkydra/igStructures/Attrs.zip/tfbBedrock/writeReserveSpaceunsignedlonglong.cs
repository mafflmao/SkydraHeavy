namespace LibSkydra
{
    public class writeReserveSpaceunsignedlonglong : igObject 
    {
        public writeReserveSpaceunsignedlonglong(IGZ igz) : base(igz) { } 
    }
}
