namespace LibSkydra
{
    public class countActorsSg : igObject 
    {
        public countActorsSg(IGZ igz) : base(igz) { } 
    }
}
