namespace LibSkydra
{
    public class getActorintSg : igObject 
    {
        public getActorintSg(IGZ igz) : base(igz) { } 
    }
}
