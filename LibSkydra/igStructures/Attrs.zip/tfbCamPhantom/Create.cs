namespace LibSkydra
{
    public class Create : igObject 
    {
        public Create(IGZ igz) : base(igz) { } 
    }
}
