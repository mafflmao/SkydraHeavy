namespace LibSkydra
{
    public class s_instance : igObject 
    {
        public s_instance(IGZ igz) : base(igz) { } 
    }
}
