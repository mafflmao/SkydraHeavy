namespace LibSkydra
{
    public class AddToWorldhkpWorld : igObject 
    {
        public AddToWorldhkpWorld(IGZ igz) : base(igz) { } 
    }
}
