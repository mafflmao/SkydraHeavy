namespace LibSkydra
{
    public class GetShapeHeightconst : igObject 
    {
        public GetShapeHeightconst(IGZ igz) : base(igz) { } 
    }
}
