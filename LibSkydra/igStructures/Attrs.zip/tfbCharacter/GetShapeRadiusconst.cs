namespace LibSkydra
{
    public class GetShapeRadiusconst : igObject 
    {
        public GetShapeRadiusconst(IGZ igz) : base(igz) { } 
    }
}
