namespace LibSkydra
{
    public class RemoveFromWorld : igObject 
    {
        public RemoveFromWorld(IGZ igz) : base(igz) { } 
    }
}
