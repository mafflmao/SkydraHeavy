namespace LibSkydra
{
    public class alignCharacterWithProxyhkStepInfoconsttfbPhysics : igObject 
    {
        public alignCharacterWithProxyhkStepInfoconsttfbPhysics(IGZ igz) : base(igz) { } 
    }
}
