namespace LibSkydra
{
    public class getWorldObject : igObject 
    {
        public getWorldObject(IGZ igz) : base(igz) { } 
    }
}
