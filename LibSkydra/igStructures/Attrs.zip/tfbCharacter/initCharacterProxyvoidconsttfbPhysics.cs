namespace LibSkydra
{
    public class initCharacterProxyvoidconsttfbPhysics : igObject 
    {
        public initCharacterProxyvoidconsttfbPhysics(IGZ igz) : base(igz) { } 
    }
}
