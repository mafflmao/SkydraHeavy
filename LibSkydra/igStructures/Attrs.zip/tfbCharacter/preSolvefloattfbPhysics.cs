namespace LibSkydra
{
    public class preSolvefloattfbPhysics : igObject 
    {
        public preSolvefloattfbPhysics(IGZ igz) : base(igz) { } 
    }
}
