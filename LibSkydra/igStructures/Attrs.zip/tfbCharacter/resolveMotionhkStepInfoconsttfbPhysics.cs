namespace LibSkydra
{
    public class resolveMotionhkStepInfoconsttfbPhysics : igObject 
    {
        public resolveMotionhkStepInfoconsttfbPhysics(IGZ igz) : base(igz) { } 
    }
}
