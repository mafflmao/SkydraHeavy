namespace LibSkydra
{
    public class tfbCharacter : igObject 
    {
        public tfbCharacter(IGZ igz) : base(igz) { } 
    }
}
