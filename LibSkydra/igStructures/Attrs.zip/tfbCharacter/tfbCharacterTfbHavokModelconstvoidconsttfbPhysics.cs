namespace LibSkydra
{
    public class tfbCharacterTfbHavokModelconstvoidconsttfbPhysics : igObject 
    {
        public tfbCharacterTfbHavokModelconstvoidconsttfbPhysics(IGZ igz) : base(igz) { } 
    }
}
