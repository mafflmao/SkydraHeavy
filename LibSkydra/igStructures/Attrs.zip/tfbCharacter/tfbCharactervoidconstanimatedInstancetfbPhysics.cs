namespace LibSkydra
{
    public class tfbCharactervoidconstanimatedInstancetfbPhysics : igObject 
    {
        public tfbCharactervoidconstanimatedInstancetfbPhysics(IGZ igz) : base(igz) { } 
    }
}
