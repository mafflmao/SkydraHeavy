namespace LibSkydra
{
    public class updateAnimationfloattfbPhysics : igObject 
    {
        public updateAnimationfloattfbPhysics(IGZ igz) : base(igz) { } 
    }
}
