namespace LibSkydra
{
    public class updateLogicfloattfbPhysics : igObject 
    {
        public updateLogicfloattfbPhysics(IGZ igz) : base(igz) { } 
    }
}
