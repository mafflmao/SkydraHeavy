namespace LibSkydra
{
    public class addCdPointhkpCdPointconst : igObject 
    {
        public addCdPointhkpCdPointconst(IGZ igz) : base(igz) { } 
    }
}
