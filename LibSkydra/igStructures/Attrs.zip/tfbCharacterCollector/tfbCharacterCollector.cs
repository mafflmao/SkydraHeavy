namespace LibSkydra
{
    public class tfbCharacterCollector : igObject 
    {
        public tfbCharacterCollector(IGZ igz) : base(igz) { } 
    }
}
