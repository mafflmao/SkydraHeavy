namespace LibSkydra
{
    public class AppendObjectMessage : igObject 
    {
        public AppendObjectMessage(IGZ igz) : base(igz) { } 
    }
}
