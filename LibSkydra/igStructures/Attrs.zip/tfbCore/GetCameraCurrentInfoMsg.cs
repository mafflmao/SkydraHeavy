namespace LibSkydra
{
    public class GetCameraCurrentInfoMsg : igObject 
    {
        public GetCameraCurrentInfoMsg(IGZ igz) : base(igz) { } 
    }
}
