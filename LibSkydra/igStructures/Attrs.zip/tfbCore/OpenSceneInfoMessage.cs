namespace LibSkydra
{
    public class OpenSceneInfoMessage : igObject 
    {
        public OpenSceneInfoMessage(IGZ igz) : base(igz) { } 
    }
}
