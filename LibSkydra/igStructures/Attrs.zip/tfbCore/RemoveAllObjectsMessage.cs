namespace LibSkydra
{
    public class RemoveAllObjectsMessage : igObject 
    {
        public RemoveAllObjectsMessage(IGZ igz) : base(igz) { } 
    }
}
