namespace LibSkydra
{
    public class SplashData : igObject 
    {
        public SplashData(IGZ igz) : base(igz) { } 
    }
}
