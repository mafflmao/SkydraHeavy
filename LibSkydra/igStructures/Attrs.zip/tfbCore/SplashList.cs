namespace LibSkydra
{
    public class SplashList : igObject 
    {
        public SplashList(IGZ igz) : base(igz) { } 
    }
}
