namespace LibSkydra
{
    public class SwitchLevelMessage : igObject 
    {
        public SwitchLevelMessage(IGZ igz) : base(igz) { } 
    }
}
