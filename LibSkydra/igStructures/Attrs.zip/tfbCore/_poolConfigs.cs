namespace LibSkydra
{
    public class _poolConfigs : igObject 
    {
        public _poolConfigs(IGZ igz) : base(igz) { } 
    }
}
