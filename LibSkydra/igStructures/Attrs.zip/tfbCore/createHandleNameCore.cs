namespace LibSkydra
{
    public class createHandleNameCore : igObject 
    {
        public createHandleNameCore(IGZ igz) : base(igz) { } 
    }
}
