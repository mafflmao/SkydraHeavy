namespace LibSkydra
{
    public class igTimingBar : igObject 
    {
        public igTimingBar(IGZ igz) : base(igz) { } 
    }
}
