namespace LibSkydra
{
    public class igTimingBarSet : igObject 
    {
        public igTimingBarSet(IGZ igz) : base(igz) { } 
    }
}
