namespace LibSkydra
{
    public class perNodeStateVecArrayMetaField : igObject 
    {
        public perNodeStateVecArrayMetaField(IGZ igz) : base(igz) { } 
    }
}
