namespace LibSkydra
{
    public class perNodeStateVecMetaField : igObject 
    {
        public perNodeStateVecMetaField(IGZ igz) : base(igz) { } 
    }
}
