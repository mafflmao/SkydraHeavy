namespace LibSkydra
{
    public class perSceneStateVecArrayMetaField : igObject 
    {
        public perSceneStateVecArrayMetaField(IGZ igz) : base(igz) { } 
    }
}
