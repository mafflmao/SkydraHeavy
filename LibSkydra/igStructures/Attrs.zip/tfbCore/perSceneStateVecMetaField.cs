namespace LibSkydra
{
    public class perSceneStateVecMetaField : igObject 
    {
        public perSceneStateVecMetaField(IGZ igz) : base(igz) { } 
    }
}
