namespace LibSkydra
{
    public class perSpriteStateVecArrayMetaField : igObject 
    {
        public perSpriteStateVecArrayMetaField(IGZ igz) : base(igz) { } 
    }
}
