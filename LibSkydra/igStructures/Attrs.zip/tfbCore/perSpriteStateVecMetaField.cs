namespace LibSkydra
{
    public class perSpriteStateVecMetaField : igObject 
    {
        public perSpriteStateVecMetaField(IGZ igz) : base(igz) { } 
    }
}
