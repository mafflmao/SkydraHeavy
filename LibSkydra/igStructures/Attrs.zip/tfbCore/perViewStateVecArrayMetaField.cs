namespace LibSkydra
{
    public class perViewStateVecArrayMetaField : igObject 
    {
        public perViewStateVecArrayMetaField(IGZ igz) : base(igz) { } 
    }
}
