namespace LibSkydra
{
    public class perViewStateVecMetaField : igObject 
    {
        public perViewStateVecMetaField(IGZ igz) : base(igz) { } 
    }
}
