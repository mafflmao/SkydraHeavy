namespace LibSkydra
{
    public class registerEffectWithHandleManagerSg : igObject 
    {
        public registerEffectWithHandleManagerSg(IGZ igz) : base(igz) { } 
    }
}
