namespace LibSkydra
{
    public class registerImageWithHandleManagerGfx : igObject 
    {
        public registerImageWithHandleManagerGfx(IGZ igz) : base(igz) { } 
    }
}
