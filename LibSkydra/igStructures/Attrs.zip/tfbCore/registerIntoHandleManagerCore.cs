namespace LibSkydra
{
    public class registerIntoHandleManagerCore : igObject 
    {
        public registerIntoHandleManagerCore(IGZ igz) : base(igz) { } 
    }
}
