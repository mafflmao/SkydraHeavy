namespace LibSkydra
{
    public class registerSystemMaterialWithHandleManagerSg : igObject 
    {
        public registerSystemMaterialWithHandleManagerSg(IGZ igz) : base(igz) { } 
    }
}
