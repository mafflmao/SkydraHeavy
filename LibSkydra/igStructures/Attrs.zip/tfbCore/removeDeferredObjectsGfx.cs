namespace LibSkydra
{
    public class removeDeferredObjectsGfx : igObject 
    {
        public removeDeferredObjectsGfx(IGZ igz) : base(igz) { } 
    }
}
