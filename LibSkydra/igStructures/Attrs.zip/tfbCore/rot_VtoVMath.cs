namespace LibSkydra
{
    public class rot_VtoVMath : igObject 
    {
        public rot_VtoVMath(IGZ igz) : base(igz) { } 
    }
}
