namespace LibSkydra
{
    public class sceneState : igObject 
    {
        public sceneState(IGZ igz) : base(igz) { } 
    }
}
