namespace LibSkydra
{
    public class tfbApplication : igObject 
    {
        public tfbApplication(IGZ igz) : base(igz) { } 
    }
}
