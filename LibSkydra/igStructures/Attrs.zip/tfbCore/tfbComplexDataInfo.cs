namespace LibSkydra
{
	public class tfbComplexDataInfo : tfbInfo
	{
		public tfbComplexDataInfo(IGZ igz) : base(igz){}
	}
}