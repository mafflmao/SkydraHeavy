namespace LibSkydra
{
    public class tfbComplexDataInfoList : igObject 
    {
        public tfbComplexDataInfoList(IGZ igz) : base(igz) { } 
    }
}
