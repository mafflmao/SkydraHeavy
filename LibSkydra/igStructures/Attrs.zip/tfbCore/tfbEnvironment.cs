namespace LibSkydra
{
    public class tfbEnvironment : igObject 
    {
        public tfbEnvironment(IGZ igz) : base(igz) { } 
    }
}
