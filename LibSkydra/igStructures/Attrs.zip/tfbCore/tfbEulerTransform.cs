namespace LibSkydra
{
    public class tfbEulerTransform : igObject 
    {
        public tfbEulerTransform(IGZ igz) : base(igz) { } 
    }
}
