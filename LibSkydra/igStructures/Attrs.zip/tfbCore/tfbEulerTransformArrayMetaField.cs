namespace LibSkydra
{
    public class tfbEulerTransformArrayMetaField : igObject 
    {
        public tfbEulerTransformArrayMetaField(IGZ igz) : base(igz) { } 
    }
}
