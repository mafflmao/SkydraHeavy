namespace LibSkydra
{
    public class tfbGameEvents : igObject 
    {
        public tfbGameEvents(IGZ igz) : base(igz) { } 
    }
}
