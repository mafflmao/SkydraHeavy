namespace LibSkydra
{
    public class tfbGameEventsArrayMetaField : igObject 
    {
        public tfbGameEventsArrayMetaField(IGZ igz) : base(igz) { } 
    }
}
