namespace LibSkydra
{
    public class tfbGameEventsMetaField : igObject 
    {
        public tfbGameEventsMetaField(IGZ igz) : base(igz) { } 
    }
}
