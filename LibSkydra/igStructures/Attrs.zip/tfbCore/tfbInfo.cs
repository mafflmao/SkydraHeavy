namespace LibSkydra
{
	public class tfbInfo : igInfo
	{
		public tfbInfo(IGZ igz) : base(igz){}
	}
}