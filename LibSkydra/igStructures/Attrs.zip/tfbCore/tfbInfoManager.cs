namespace LibSkydra
{
    public class tfbInfoManager : igObject 
    {
        public tfbInfoManager(IGZ igz) : base(igz) { } 
    }
}
