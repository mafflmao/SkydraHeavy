namespace LibSkydra
{
    public class tfbMailbox : igObject 
    {
        public tfbMailbox(IGZ igz) : base(igz) { } 
    }
}
