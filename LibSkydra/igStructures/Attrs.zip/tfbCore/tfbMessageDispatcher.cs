namespace LibSkydra
{
    public class tfbMessageDispatcher : igObject 
    {
        public tfbMessageDispatcher(IGZ igz) : base(igz) { } 
    }
}
