namespace LibSkydra
{
    public class tfbMessageFilter : igObject 
    {
        public tfbMessageFilter(IGZ igz) : base(igz) { } 
    }
}
