namespace LibSkydra
{
    public class tfbMessageFilterList : igObject 
    {
        public tfbMessageFilterList(IGZ igz) : base(igz) { } 
    }
}
