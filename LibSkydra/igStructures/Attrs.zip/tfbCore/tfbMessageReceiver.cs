namespace LibSkydra
{
    public class tfbMessageReceiver : igObject 
    {
        public tfbMessageReceiver(IGZ igz) : base(igz) { } 
    }
}
