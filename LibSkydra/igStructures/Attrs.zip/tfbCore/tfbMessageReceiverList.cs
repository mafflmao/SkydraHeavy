namespace LibSkydra
{
    public class tfbMessageReceiverList : igObject 
    {
        public tfbMessageReceiverList(IGZ igz) : base(igz) { } 
    }
}
