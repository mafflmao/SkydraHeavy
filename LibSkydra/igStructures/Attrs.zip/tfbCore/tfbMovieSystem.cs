namespace LibSkydra
{
    public class tfbMovieSystem : igObject 
    {
        public tfbMovieSystem(IGZ igz) : base(igz) { } 
    }
}
