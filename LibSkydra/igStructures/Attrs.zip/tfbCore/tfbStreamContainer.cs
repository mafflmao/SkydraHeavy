namespace LibSkydra
{
    public class tfbStreamContainer : igObject 
    {
        public tfbStreamContainer(IGZ igz) : base(igz) { } 
    }
}
