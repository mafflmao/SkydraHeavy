namespace LibSkydra
{
    public class tfbStreamMemoryConfiguration : igObject 
    {
        public tfbStreamMemoryConfiguration(IGZ igz) : base(igz) { } 
    }
}
