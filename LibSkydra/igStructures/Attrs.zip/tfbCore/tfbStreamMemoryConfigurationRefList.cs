namespace LibSkydra
{
    public class tfbStreamMemoryConfigurationRefList : igObject 
    {
        public tfbStreamMemoryConfigurationRefList(IGZ igz) : base(igz) { } 
    }
}
