namespace LibSkydra
{
    public class tfbTransform : igObject 
    {
        public tfbTransform(IGZ igz) : base(igz) { } 
    }
}
