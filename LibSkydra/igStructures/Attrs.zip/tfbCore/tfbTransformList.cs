namespace LibSkydra
{
    public class tfbTransformList : igObject 
    {
        public tfbTransformList(IGZ igz) : base(igz) { } 
    }
}
