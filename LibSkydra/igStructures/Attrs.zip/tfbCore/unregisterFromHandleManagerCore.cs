namespace LibSkydra
{
    public class unregisterFromHandleManagerCore : igObject 
    {
        public unregisterFromHandleManagerCore(IGZ igz) : base(igz) { } 
    }
}
