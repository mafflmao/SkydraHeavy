namespace LibSkydra
{
    public class CutsceneInfoList : igObject 
    {
        public CutsceneInfoList(IGZ igz) : base(igz) { } 
    }
}
