namespace LibSkydra
{
    public class CutsceneResolver : igObject 
    {
        public CutsceneResolver(IGZ igz) : base(igz) { } 
    }
}
