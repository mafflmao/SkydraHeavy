namespace LibSkydra
{
    public class cutsceneDataInfoImpl : igObject 
    {
        public cutsceneDataInfoImpl(IGZ igz) : base(igz) { } 
    }
}
