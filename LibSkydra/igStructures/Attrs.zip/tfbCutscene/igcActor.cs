namespace LibSkydra
{
    public class igcActor : igObject 
    {
        public igcActor(IGZ igz) : base(igz) { } 
    }
}
