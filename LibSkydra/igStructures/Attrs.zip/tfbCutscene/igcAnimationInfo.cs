namespace LibSkydra
{
    public class igcAnimationInfo : igNamedObject
    {
        public igcAnimationInfo(IGZ igz) : base(igz) { } 
    }
}
