namespace LibSkydra
{
    public class igcAnimationInfoList : igObject 
    {
        public igcAnimationInfoList(IGZ igz) : base(igz) { } 
    }
}
