namespace LibSkydra
{
    public class igcModelInfo : igObject 
    {
        public igcModelInfo(IGZ igz) : base(igz) { } 
    }
}
