namespace LibSkydra
{
    public class igcModelInfoList : igObject 
    {
        public igcModelInfoList(IGZ igz) : base(igz) { } 
    }
}
