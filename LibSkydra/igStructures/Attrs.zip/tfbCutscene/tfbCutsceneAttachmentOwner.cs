namespace LibSkydra
{
    public class tfbCutsceneAttachmentOwner : igObject 
    {
        public tfbCutsceneAttachmentOwner(IGZ igz) : base(igz) { } 
    }
}
