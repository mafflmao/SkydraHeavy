namespace LibSkydra
{
    public class tfbCutsceneDataInfo : igObject 
    {
        public tfbCutsceneDataInfo(IGZ igz) : base(igz) { } 
    }
}
