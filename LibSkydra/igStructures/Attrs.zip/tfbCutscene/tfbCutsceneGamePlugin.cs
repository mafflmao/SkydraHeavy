namespace LibSkydra
{
    public class tfbCutsceneGamePlugin : igObject 
    {
        public tfbCutsceneGamePlugin(IGZ igz) : base(igz) { } 
    }
}
