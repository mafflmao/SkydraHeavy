﻿namespace LibSkydra
{
    public class tfbCutsceneInfo : tfbComplexDataInfo
    {

        public tfbCutsceneInfo(IGZ igz) : base(igz) { }
    }
}