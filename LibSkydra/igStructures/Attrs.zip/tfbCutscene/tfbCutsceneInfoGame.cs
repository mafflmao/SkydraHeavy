namespace LibSkydra
{
    public class tfbCutsceneInfoGame : igObject 
    {
        public tfbCutsceneInfoGame(IGZ igz) : base(igz) { } 
    }
}
