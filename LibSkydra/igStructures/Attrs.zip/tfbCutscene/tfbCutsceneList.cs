namespace LibSkydra
{
    public class tfbCutsceneList : igObject 
    {
        public tfbCutsceneList(IGZ igz) : base(igz) { } 
    }
}
