namespace LibSkydra
{
    public class tfbCutsceneSystem : igObject 
    {
        public tfbCutsceneSystem(IGZ igz) : base(igz) { } 
    }
}
