namespace LibSkydra
{
    public class tfbCutsceneUpdateGame : igObject 
    {
        public tfbCutsceneUpdateGame(IGZ igz) : base(igz) { } 
    }
}
