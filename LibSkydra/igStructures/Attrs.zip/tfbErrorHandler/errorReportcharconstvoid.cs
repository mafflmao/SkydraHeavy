namespace LibSkydra
{
    public class errorReportcharconstvoid : igObject 
    {
        public errorReportcharconstvoid(IGZ igz) : base(igz) { } 
    }
}
