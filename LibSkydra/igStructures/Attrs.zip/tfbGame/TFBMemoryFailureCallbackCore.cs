namespace LibSkydra
{
    public class TFBMemoryFailureCallbackCore : igObject 
    {
        public TFBMemoryFailureCallbackCore(IGZ igz) : base(igz) { } 
    }
}
