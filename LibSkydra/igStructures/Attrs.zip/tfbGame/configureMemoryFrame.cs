namespace LibSkydra
{
    public class configureMemoryFrame : igObject 
    {
        public configureMemoryFrame(IGZ igz) : base(igz) { } 
    }
}
