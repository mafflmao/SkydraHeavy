namespace LibSkydra
{
    public class deviceGetLanguagetfbCore : igObject 
    {
        public deviceGetLanguagetfbCore(IGZ igz) : base(igz) { } 
    }
}
