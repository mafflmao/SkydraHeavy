namespace LibSkydra
{
    public class dumpMemoryLeaks : igObject 
    {
        public dumpMemoryLeaks(IGZ igz) : base(igz) { } 
    }
}
