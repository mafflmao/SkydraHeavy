namespace LibSkydra
{
    public class dumpMemoryToFilebool : igObject 
    {
        public dumpMemoryToFilebool(IGZ igz) : base(igz) { } 
    }
}
