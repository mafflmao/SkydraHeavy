namespace LibSkydra
{
    public class dumpMemorybool : igObject 
    {
        public dumpMemorybool(IGZ igz) : base(igz) { } 
    }
}
