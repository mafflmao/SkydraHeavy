namespace LibSkydra
{
    public class frameAdvance : igObject 
    {
        public frameAdvance(IGZ igz) : base(igz) { } 
    }
}
