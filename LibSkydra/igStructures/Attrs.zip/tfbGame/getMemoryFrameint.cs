namespace LibSkydra
{
    public class getMemoryFrameint : igObject 
    {
        public getMemoryFrameint(IGZ igz) : base(igz) { } 
    }
}
