namespace LibSkydra
{
    public class loadContext : igObject 
    {
        public loadContext(IGZ igz) : base(igz) { } 
    }
}
