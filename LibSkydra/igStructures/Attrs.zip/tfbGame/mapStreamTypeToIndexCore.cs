namespace LibSkydra
{
    public class mapStreamTypeToIndexCore : igObject 
    {
        public mapStreamTypeToIndexCore(IGZ igz) : base(igz) { } 
    }
}
