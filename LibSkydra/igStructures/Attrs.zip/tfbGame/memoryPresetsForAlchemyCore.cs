namespace LibSkydra
{
    public class memoryPresetsForAlchemyCore : igObject 
    {
        public memoryPresetsForAlchemyCore(IGZ igz) : base(igz) { } 
    }
}
