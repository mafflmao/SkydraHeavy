namespace LibSkydra
{
    public class removeObjectsGfx : igObject 
    {
        public removeObjectsGfx(IGZ igz) : base(igz) { } 
    }
}
