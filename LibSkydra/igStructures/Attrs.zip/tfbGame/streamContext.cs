namespace LibSkydra
{
    public class streamContext : igObject 
    {
        public streamContext(IGZ igz) : base(igz) { } 
    }
}
