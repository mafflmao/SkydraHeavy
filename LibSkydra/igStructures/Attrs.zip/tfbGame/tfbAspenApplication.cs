namespace LibSkydra
{
    public class tfbAspenApplication : igObject 
    {
        public tfbAspenApplication(IGZ igz) : base(igz) { } 
    }
}
