namespace LibSkydra
{
    public class tfbAspenHardwareUpdate : igObject 
    {
        public tfbAspenHardwareUpdate(IGZ igz) : base(igz) { } 
    }
}
