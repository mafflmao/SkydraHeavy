namespace LibSkydra
{
    public class tfbHardwareImplPlugin : igObject 
    {
        public tfbHardwareImplPlugin(IGZ igz) : base(igz) { } 
    }
}
