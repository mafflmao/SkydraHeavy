namespace LibSkydra
{
    public class tfbHardwareUpdate : igObject 
    {
        public tfbHardwareUpdate(IGZ igz) : base(igz) { } 
    }
}
