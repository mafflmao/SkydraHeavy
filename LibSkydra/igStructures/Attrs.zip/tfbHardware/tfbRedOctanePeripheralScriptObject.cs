namespace LibSkydra
{
    public class tfbRedOctanePeripheralScriptObject : igObject 
    {
        public tfbRedOctanePeripheralScriptObject(IGZ igz) : base(igz) { } 
    }
}
