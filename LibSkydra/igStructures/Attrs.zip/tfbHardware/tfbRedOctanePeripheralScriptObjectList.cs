namespace LibSkydra
{
    public class tfbRedOctanePeripheralScriptObjectList : igObject 
    {
        public tfbRedOctanePeripheralScriptObjectList(IGZ igz) : base(igz) { } 
    }
}
