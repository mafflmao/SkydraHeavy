namespace LibSkydra
{
    public class tfbRedOctanePeripheralScriptObject_PortalDebug : igObject 
    {
        public tfbRedOctanePeripheralScriptObject_PortalDebug(IGZ igz) : base(igz) { } 
    }
}
