namespace LibSkydra
{
    public class tfbRedOctanePeripheralScriptObject_PortalDebug_construct_void : igObject 
    {
        public tfbRedOctanePeripheralScriptObject_PortalDebug_construct_void(IGZ igz) : base(igz) { } 
    }
}
