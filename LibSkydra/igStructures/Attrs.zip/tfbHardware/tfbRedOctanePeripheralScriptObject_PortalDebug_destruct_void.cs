namespace LibSkydra
{
    public class tfbRedOctanePeripheralScriptObject_PortalDebug_destruct_void : igObject 
    {
        public tfbRedOctanePeripheralScriptObject_PortalDebug_destruct_void(IGZ igz) : base(igz) { } 
    }
}
