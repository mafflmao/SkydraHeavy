namespace LibSkydra
{
    public class tfbRedOctanePeripheralSystemObject : igObject 
    {
        public tfbRedOctanePeripheralSystemObject(IGZ igz) : base(igz) { } 
    }
}
