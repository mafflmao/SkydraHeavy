namespace LibSkydra
{
    public class tfbRedOctaneTagScriptObject : igObject 
    {
        public tfbRedOctaneTagScriptObject(IGZ igz) : base(igz) { } 
    }
}
