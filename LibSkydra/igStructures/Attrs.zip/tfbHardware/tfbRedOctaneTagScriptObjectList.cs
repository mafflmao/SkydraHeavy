namespace LibSkydra
{
    public class tfbRedOctaneTagScriptObjectList : igObject 
    {
        public tfbRedOctaneTagScriptObjectList(IGZ igz) : base(igz) { } 
    }
}
