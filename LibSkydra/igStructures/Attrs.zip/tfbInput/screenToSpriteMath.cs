namespace LibSkydra
{
    public class screenToSpriteMath : igObject 
    {
        public screenToSpriteMath(IGZ igz) : base(igz) { } 
    }
}
