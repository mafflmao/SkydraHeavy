namespace LibSkydra
{
    public class tfbBleInputDevice : igObject 
    {
        public tfbBleInputDevice(IGZ igz) : base(igz) { } 
    }
}
