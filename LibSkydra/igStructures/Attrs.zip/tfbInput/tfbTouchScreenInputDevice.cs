namespace LibSkydra
{
    public class tfbTouchScreenInputDevice : igObject 
    {
        public tfbTouchScreenInputDevice(IGZ igz) : base(igz) { } 
    }
}
