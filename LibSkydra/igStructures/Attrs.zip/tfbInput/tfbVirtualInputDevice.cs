namespace LibSkydra
{
    public class tfbVirtualInputDevice : igObject 
    {
        public tfbVirtualInputDevice(IGZ igz) : base(igz) { } 
    }
}
