namespace LibSkydra
{
    public class tfbLandscape : igObject 
    {
        public tfbLandscape(IGZ igz) : base(igz) { } 
    }
}
