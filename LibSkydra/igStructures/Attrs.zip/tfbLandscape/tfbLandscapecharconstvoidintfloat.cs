namespace LibSkydra
{
    public class tfbLandscapecharconstvoidintfloat : igObject 
    {
        public tfbLandscapecharconstvoidintfloat(IGZ igz) : base(igz) { } 
    }
}
