namespace LibSkydra
{
    public class AnimationBlendInfo : igObject 
    {
        public AnimationBlendInfo(IGZ igz) : base(igz) { } 
    }
}
