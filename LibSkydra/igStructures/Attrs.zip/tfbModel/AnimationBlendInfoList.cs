namespace LibSkydra
{
    public class AnimationBlendInfoList : igObject 
    {
        public AnimationBlendInfoList(IGZ igz) : base(igz) { } 
    }
}
