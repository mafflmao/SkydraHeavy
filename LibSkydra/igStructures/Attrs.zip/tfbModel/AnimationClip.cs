namespace LibSkydra
{
    public class AnimationClip : igObject 
    {
        public AnimationClip(IGZ igz) : base(igz) { } 
    }
}
