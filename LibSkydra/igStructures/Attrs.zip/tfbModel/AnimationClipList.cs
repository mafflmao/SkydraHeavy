namespace LibSkydra
{
    public class AnimationClipList : igObject 
    {
        public AnimationClipList(IGZ igz) : base(igz) { } 
    }
}
