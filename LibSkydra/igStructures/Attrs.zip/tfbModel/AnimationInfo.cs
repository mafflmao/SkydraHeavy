namespace LibSkydra
{
    public class AnimationInfo : igNamedObject 
    {
        public AnimationInfo(IGZ igz) : base(igz) { } 
    }
}
