namespace LibSkydra
{
    public class AnimationInfoList : igObject 
    {
        public AnimationInfoList(IGZ igz) : base(igz) { } 
    }
}
