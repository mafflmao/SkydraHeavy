namespace LibSkydra
{
    public class AnimationInfoResolver : igObject 
    {
        public AnimationInfoResolver(IGZ igz) : base(igz) { } 
    }
}
