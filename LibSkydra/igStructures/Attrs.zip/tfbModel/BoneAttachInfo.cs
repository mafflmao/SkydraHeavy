namespace LibSkydra
{
    public class BoneAttachInfo : igObject 
    {
        public BoneAttachInfo(IGZ igz) : base(igz) { } 
    }
}
