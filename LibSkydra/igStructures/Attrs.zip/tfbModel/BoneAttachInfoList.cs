namespace LibSkydra
{
    public class BoneAttachInfoList : igObject 
    {
        public BoneAttachInfoList(IGZ igz) : base(igz) { } 
    }
}
