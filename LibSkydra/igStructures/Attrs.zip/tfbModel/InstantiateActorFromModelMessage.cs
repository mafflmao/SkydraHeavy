namespace LibSkydra
{
    public class InstantiateActorFromModelMessage : igObject 
    {
        public InstantiateActorFromModelMessage(IGZ igz) : base(igz) { } 
    }
}
