namespace LibSkydra
{
    public class ModelInfoList : igObject 
    {
        public ModelInfoList(IGZ igz) : base(igz) { } 
    }
}
