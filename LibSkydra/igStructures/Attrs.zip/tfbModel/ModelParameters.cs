namespace LibSkydra
{
    public class ModelParameters : igObject 
    {
        public ModelParameters(IGZ igz) : base(igz) { } 
    }
}
