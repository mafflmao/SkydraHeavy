namespace LibSkydra
{
    public class ModelPhysics : igObject 
    {
        public ModelPhysics(IGZ igz) : base(igz) { } 
    }
}
