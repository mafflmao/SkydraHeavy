namespace LibSkydra
{
    public class ModelSoundList : igObject 
    {
        public ModelSoundList(IGZ igz) : base(igz) { } 
    }
}
