namespace LibSkydra
{
    public class RigidBodyParameters : igObject 
    {
        public RigidBodyParameters(IGZ igz) : base(igz) { } 
    }
}
