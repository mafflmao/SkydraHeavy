namespace LibSkydra
{
    public class VehicleParameters : igObject 
    {
        public VehicleParameters(IGZ igz) : base(igz) { } 
    }
}
