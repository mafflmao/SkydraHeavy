namespace LibSkydra
{
    public class tfbAnimationInfo : igNamedObject
    {
        public tfbAnimationInfo(IGZ igz) : base(igz) { } 
    }
}
