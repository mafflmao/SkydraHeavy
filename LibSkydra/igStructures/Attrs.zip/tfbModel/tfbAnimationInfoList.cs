namespace LibSkydra
{
    public class tfbAnimationInfoList : igObject 
    {
        public tfbAnimationInfoList(IGZ igz) : base(igz) { } 
    }
}
