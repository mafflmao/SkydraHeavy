namespace LibSkydra
{
    public class tfbAnimationInfoViseme : igObject 
    {
        public tfbAnimationInfoViseme(IGZ igz) : base(igz) { } 
    }
}
