namespace LibSkydra
{
    public class tfbAnimationState : igObject 
    {
        public tfbAnimationState(IGZ igz) : base(igz) { } 
    }
}
