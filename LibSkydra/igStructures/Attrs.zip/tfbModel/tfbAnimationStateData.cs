namespace LibSkydra
{
    public class tfbAnimationStateData : igObject 
    {
        public tfbAnimationStateData(IGZ igz) : base(igz) { } 
    }
}
