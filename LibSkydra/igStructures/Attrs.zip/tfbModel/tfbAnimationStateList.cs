namespace LibSkydra
{
    public class tfbAnimationStateList : igObject 
    {
        public tfbAnimationStateList(IGZ igz) : base(igz) { } 
    }
}
