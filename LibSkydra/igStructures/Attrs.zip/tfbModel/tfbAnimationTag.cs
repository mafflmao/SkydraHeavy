namespace LibSkydra
{
    public class tfbAnimationTag : igObject 
    {
        public tfbAnimationTag(IGZ igz) : base(igz) { } 
    }
}
