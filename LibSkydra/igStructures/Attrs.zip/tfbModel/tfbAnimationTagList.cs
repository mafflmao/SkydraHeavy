namespace LibSkydra
{
    public class tfbAnimationTagList : igObject 
    {
        public tfbAnimationTagList(IGZ igz) : base(igz) { } 
    }
}
