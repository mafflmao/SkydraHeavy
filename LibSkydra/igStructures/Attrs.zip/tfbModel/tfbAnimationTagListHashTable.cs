namespace LibSkydra
{
    public class tfbAnimationTagListHashTable : igObject 
    {
        public tfbAnimationTagListHashTable(IGZ igz) : base(igz) { } 
    }
}
