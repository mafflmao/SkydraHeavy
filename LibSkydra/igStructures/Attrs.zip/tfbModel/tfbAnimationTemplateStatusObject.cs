namespace LibSkydra
{
    public class tfbAnimationTemplateStatusObject : igObject 
    {
        public tfbAnimationTemplateStatusObject(IGZ igz) : base(igz) { } 
    }
}
