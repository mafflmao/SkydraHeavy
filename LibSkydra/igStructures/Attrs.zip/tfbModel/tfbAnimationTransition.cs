namespace LibSkydra
{
    public class tfbAnimationTransition : igObject 
    {
        public tfbAnimationTransition(IGZ igz) : base(igz) { } 
    }
}
