namespace LibSkydra
{
    public class tfbAnimationTransitionBasic : igObject 
    {
        public tfbAnimationTransitionBasic(IGZ igz) : base(igz) { } 
    }
}
