namespace LibSkydra
{
    public class tfbAnimationTransitionGeneric : igObject 
    {
        public tfbAnimationTransitionGeneric(IGZ igz) : base(igz) { } 
    }
}
