namespace LibSkydra
{
    public class tfbAnimationTransitionList : igObject 
    {
        public tfbAnimationTransitionList(IGZ igz) : base(igz) { } 
    }
}
