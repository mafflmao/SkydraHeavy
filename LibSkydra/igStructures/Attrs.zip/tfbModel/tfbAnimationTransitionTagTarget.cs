namespace LibSkydra
{
    public class tfbAnimationTransitionTagTarget : igObject 
    {
        public tfbAnimationTransitionTagTarget(IGZ igz) : base(igz) { } 
    }
}
