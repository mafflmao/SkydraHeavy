namespace LibSkydra
{
    public class tfbAnimationTransitionTagTargetHybrid : igObject 
    {
        public tfbAnimationTransitionTagTargetHybrid(IGZ igz) : base(igz) { } 
    }
}
