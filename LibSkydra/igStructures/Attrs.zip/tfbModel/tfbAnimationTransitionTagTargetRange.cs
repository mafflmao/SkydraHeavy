namespace LibSkydra
{
    public class tfbAnimationTransitionTagTargetRange : igObject 
    {
        public tfbAnimationTransitionTagTargetRange(IGZ igz) : base(igz) { } 
    }
}
