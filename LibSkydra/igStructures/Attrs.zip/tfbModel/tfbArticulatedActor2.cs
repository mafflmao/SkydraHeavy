namespace LibSkydra
{
    public class tfbArticulatedActor2 : igObject 
    {
        public tfbArticulatedActor2(IGZ igz) : base(igz) { } 
    }
}
