namespace LibSkydra
{
    public class tfbArticulatedActorTransform : igObject 
    {
        public tfbArticulatedActorTransform(IGZ igz) : base(igz) { } 
    }
}
