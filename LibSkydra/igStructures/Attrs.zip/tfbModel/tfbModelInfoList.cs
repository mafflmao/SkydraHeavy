namespace LibSkydra
{
    public class tfbModelInfoList : igObject 
    {
        public tfbModelInfoList(IGZ igz) : base(igz) { } 
    }
}
