namespace LibSkydra
{
    public class tfbPhysicsCombiner : igObject 
    {
        public tfbPhysicsCombiner(IGZ igz) : base(igz) { } 
    }
}
