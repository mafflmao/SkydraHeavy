namespace LibSkydra
{
    public class tfbRandomAnimationState : igObject 
    {
        public tfbRandomAnimationState(IGZ igz) : base(igz) { } 
    }
}
