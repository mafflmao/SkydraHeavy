namespace LibSkydra
{
    public class tfbSkinningCombiner : igObject 
    {
        public tfbSkinningCombiner(IGZ igz) : base(igz) { } 
    }
}
