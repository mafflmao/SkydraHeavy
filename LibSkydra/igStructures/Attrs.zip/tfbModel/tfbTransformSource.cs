namespace LibSkydra
{
    public class tfbTransformSource : igObject 
    {
        public tfbTransformSource(IGZ igz) : base(igz) { } 
    }
}
