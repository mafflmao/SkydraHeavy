namespace LibSkydra
{
    public class tfbVisemeInfoList : igObject 
    {
        public tfbVisemeInfoList(IGZ igz) : base(igz) { } 
    }
}
