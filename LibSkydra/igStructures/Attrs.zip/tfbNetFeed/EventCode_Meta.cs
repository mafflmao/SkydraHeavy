namespace LibSkydra
{
    public class EventCode_Meta : igObject 
    {
        public EventCode_Meta(IGZ igz) : base(igz) { } 
    }
}
