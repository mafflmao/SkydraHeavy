namespace LibSkydra
{
    public class compactPortalDataunsignedcharconstunsignedcharunsignedshort : igObject 
    {
        public compactPortalDataunsignedcharconstunsignedcharunsignedshort(IGZ igz) : base(igz) { } 
    }
}
