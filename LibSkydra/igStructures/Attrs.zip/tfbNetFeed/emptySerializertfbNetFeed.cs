namespace LibSkydra
{
    public class emptySerializertfbNetFeed : igObject 
    {
        public emptySerializertfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
