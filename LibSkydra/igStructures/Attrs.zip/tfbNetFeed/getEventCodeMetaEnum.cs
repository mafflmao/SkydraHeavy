namespace LibSkydra
{
    public class getEventCodeMetaEnum : igObject 
    {
        public getEventCodeMetaEnum(IGZ igz) : base(igz) { } 
    }
}
