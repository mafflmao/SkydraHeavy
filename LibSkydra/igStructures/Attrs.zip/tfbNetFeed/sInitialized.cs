namespace LibSkydra
{
    public class sInitialized : igObject 
    {
        public sInitialized(IGZ igz) : base(igz) { } 
    }
}
