namespace LibSkydra
{
    public class sLogIndex : igObject 
    {
        public sLogIndex(IGZ igz) : base(igz) { } 
    }
}
