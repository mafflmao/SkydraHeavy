namespace LibSkydra
{
    public class sSystemTicksPerSecond : igObject 
    {
        public sSystemTicksPerSecond(IGZ igz) : base(igz) { } 
    }
}
