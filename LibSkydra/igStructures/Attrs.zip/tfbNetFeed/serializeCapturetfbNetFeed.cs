namespace LibSkydra
{
    public class serializeCapturetfbNetFeed : igObject 
    {
        public serializeCapturetfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
