namespace LibSkydra
{
    public class serializeCardGametfbNetFeed : igObject 
    {
        public serializeCardGametfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
