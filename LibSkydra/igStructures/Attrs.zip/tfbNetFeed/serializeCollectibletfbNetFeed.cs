namespace LibSkydra
{
    public class serializeCollectibletfbNetFeed : igObject 
    {
        public serializeCollectibletfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
