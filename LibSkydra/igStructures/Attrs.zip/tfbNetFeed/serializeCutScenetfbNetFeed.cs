namespace LibSkydra
{
    public class serializeCutScenetfbNetFeed : igObject 
    {
        public serializeCutScenetfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
