namespace LibSkydra
{
    public class serializeDeathtfbNetFeed : igObject 
    {
        public serializeDeathtfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
