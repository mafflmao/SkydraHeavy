namespace LibSkydra
{
    public class serializeEndLeveltfbNetFeed : igObject 
    {
        public serializeEndLeveltfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
