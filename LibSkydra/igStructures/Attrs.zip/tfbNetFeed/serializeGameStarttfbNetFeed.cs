namespace LibSkydra
{
    public class serializeGameStarttfbNetFeed : igObject 
    {
        public serializeGameStarttfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
