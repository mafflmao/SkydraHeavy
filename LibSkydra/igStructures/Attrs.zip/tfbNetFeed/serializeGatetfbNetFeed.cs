namespace LibSkydra
{
    public class serializeGatetfbNetFeed : igObject 
    {
        public serializeGatetfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
