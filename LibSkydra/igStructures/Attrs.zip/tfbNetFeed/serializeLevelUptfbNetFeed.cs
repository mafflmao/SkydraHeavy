namespace LibSkydra
{
    public class serializeLevelUptfbNetFeed : igObject 
    {
        public serializeLevelUptfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
