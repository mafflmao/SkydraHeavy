namespace LibSkydra
{
    public class serializeLockGametfbNetFeed : igObject 
    {
        public serializeLockGametfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
