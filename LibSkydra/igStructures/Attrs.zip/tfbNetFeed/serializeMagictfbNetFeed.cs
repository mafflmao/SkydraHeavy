namespace LibSkydra
{
    public class serializeMagictfbNetFeed : igObject 
    {
        public serializeMagictfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
