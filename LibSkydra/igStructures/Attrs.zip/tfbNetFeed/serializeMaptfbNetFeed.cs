namespace LibSkydra
{
    public class serializeMaptfbNetFeed : igObject 
    {
        public serializeMaptfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
