namespace LibSkydra
{
    public class serializeMenutfbNetFeed : igObject 
    {
        public serializeMenutfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
