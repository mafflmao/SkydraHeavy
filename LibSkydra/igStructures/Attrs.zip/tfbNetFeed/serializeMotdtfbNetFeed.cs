namespace LibSkydra
{
    public class serializeMotdtfbNetFeed : igObject 
    {
        public serializeMotdtfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
