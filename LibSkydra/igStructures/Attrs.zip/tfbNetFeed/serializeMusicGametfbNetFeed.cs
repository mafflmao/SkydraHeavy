namespace LibSkydra
{
    public class serializeMusicGametfbNetFeed : igObject 
    {
        public serializeMusicGametfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
