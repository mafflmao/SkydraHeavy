namespace LibSkydra
{
    public class serializePortaltfbNetFeed : igObject 
    {
        public serializePortaltfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
