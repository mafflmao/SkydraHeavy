namespace LibSkydra
{
    public class serializePurchasetfbNetFeed : igObject 
    {
        public serializePurchasetfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
