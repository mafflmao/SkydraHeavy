namespace LibSkydra
{
    public class serializeQuestGametfbNetFeed : igObject 
    {
        public serializeQuestGametfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
