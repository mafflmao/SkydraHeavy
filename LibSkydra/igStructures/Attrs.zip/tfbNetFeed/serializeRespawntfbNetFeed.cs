namespace LibSkydra
{
    public class serializeRespawntfbNetFeed : igObject 
    {
        public serializeRespawntfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
