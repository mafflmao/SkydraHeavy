namespace LibSkydra
{
    public class serializeSessiontfbNetFeed : igObject 
    {
        public serializeSessiontfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
