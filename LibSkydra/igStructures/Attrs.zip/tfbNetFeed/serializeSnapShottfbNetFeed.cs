namespace LibSkydra
{
    public class serializeSnapShottfbNetFeed : igObject 
    {
        public serializeSnapShottfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
