namespace LibSkydra
{
    public class serializeSoulGemtfbNetFeed : igObject 
    {
        public serializeSoulGemtfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
