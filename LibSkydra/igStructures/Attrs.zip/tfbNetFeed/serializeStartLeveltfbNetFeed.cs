namespace LibSkydra
{
    public class serializeStartLeveltfbNetFeed : igObject 
    {
        public serializeStartLeveltfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
