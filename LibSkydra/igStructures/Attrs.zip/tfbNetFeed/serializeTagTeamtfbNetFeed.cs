namespace LibSkydra
{
    public class serializeTagTeamtfbNetFeed : igObject 
    {
        public serializeTagTeamtfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
