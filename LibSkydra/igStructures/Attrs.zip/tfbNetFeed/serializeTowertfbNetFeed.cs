namespace LibSkydra
{
    public class serializeTowertfbNetFeed : igObject 
    {
        public serializeTowertfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
