namespace LibSkydra
{
    public class serializeVillainGametfbNetFeed : igObject 
    {
        public serializeVillainGametfbNetFeed(IGZ igz) : base(igz) { } 
    }
}
