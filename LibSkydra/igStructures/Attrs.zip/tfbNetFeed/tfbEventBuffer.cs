namespace LibSkydra
{
    public class tfbEventBuffer : igObject 
    {
        public tfbEventBuffer(IGZ igz) : base(igz) { } 
    }
}
