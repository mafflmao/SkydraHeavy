namespace LibSkydra
{
    public class tfbNetFeedConfig : igObject 
    {
        public tfbNetFeedConfig(IGZ igz) : base(igz) { } 
    }
}
